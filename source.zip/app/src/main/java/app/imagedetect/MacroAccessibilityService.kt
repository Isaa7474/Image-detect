package app.imagedetect

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.os.Handler
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.LinkedHashMap
import kotlin.math.abs
import kotlin.math.roundToInt

private data class TouchStroke(val path: Path, val startMs: Long, var endMs: Long)

class MacroAccessibilityService : AccessibilityService() {
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchDownAt = 0L
    private var touchMoved = false
    private var floatingRoot: LinearLayout? = null
    private var floatingPanel: LinearLayout? = null
    private var recordButton: TextView? = null
    private var playButton: TextView? = null
    private var pauseButton: TextView? = null
    private var stopButton: TextView? = null
    private var previousButton: TextView? = null
    private var nextButton: TextView? = null
    private var scriptLabel: TextView? = null
    private var floatingStatus: TextView? = null
    private var bubble: TextView? = null
    private var bubblePulse: android.animation.ObjectAnimator? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private val floatingBounds = Rect()
    private val recentControlBounds = Rect()
    private var recentControlTime = 0L
    private var expanded = false
    private var replacementStepId: Long? = null
    private var settingsOverlay: FloatingSettingsOverlay? = null
    private var cropOverlay: LiveCropOverlay? = null
    private var touchRelay: FrameLayout? = null
    private var touchRelayParams: WindowManager.LayoutParams? = null
    private val touchStrokes = LinkedHashMap<Int, TouchStroke>()
    private val activeTouchPointers = mutableSetOf<Int>()
    private var touchSequenceStart = 0L
    private var touchHadMultiplePointers = false
    private var touchSequenceBelongsToTarget = false
    private var touchSequenceBlockedByUi = false
    private var touchSequenceBlockedByReplay = false
    private var replayingTouch = false
    private var lastTouchDownTime = -1L
    private var lastRecordedTouchDownTime = -1L
    private var replayTouchX = Float.NaN
    private var replayTouchY = Float.NaN
    private var replayTouchGuardUntil = 0L
    private var recordingGeneration = 0L
    private var foregroundPackage: String? = null
    private var recordingTargetPackage: String? = null

    override fun onServiceConnected() {
        MacroStore.initialize(this)
        AppLanguage.initialize(this)
        instance = this
        prepareTouchRelay()
        showFloatingMenu()
        MacroStore.status = when {
            touchRelay == null -> "لایهٔ ثبت لمس نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید"
            floatingRoot == null -> "منوی شناور نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید"
            else -> "منوی شناور آماده است؛ لمس هنگام ضبط ثبت و عبور داده می‌شود"
        }
    }

    private fun prepareTouchRelay() {
        if (touchRelay != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        val relay = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            setOnTouchListener { view, event -> handleRelayTouch(view, event) }
        }
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        manager.defaultDisplay.getRealMetrics(metrics)
        val statusBarHeight = systemDimension("status_bar_height")
        val relayWidth = metrics.widthPixels.coerceAtLeast(1)
        val relayHeight = (metrics.heightPixels - statusBarHeight).coerceAtLeast(1)
        val params = WindowManager.LayoutParams(
            relayWidth,
            relayHeight,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            y = statusBarHeight
        }
        touchRelay = relay
        touchRelayParams = params
        try {
            manager.addView(relay, params)
        } catch (_: WindowManager.BadTokenException) {
            touchRelay = null
            touchRelayParams = null
            MacroStore.status = "لایهٔ ثبت لمس نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید"
        }
    }

    private fun showFloatingMenu() {
        if (floatingRoot != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (AppLanguage.current == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = rounded(0xEB0B1026.toInt(), 0xFF5B6CFF.toInt(), 18)
            elevation = dp(8).toFloat()
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (AppLanguage.current == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            isClickable = true
            visibility = View.GONE
            val availableWidth = (resources.displayMetrics.widthPixels - dp(16)).coerceAtLeast(dp(132))
            layoutParams = LinearLayout.LayoutParams(minOf(dp(132), availableWidth), LinearLayout.LayoutParams.WRAP_CONTENT)
            background = rounded(0xFF141A3A.toInt(), 0xFF4E5CD6.toInt(), 16)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val title = TextView(this).apply {
            text = AppLanguage.translate(MacroStore.scriptName)
            textSize = 10f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val settings = iconButton("⚙", "ویرایش اسکریپت", 0xFF2B3470.toInt()) {
            showSettingsOverlay()
        }
        val replace = iconButton("▧", "جایگزینی تصویر انتخاب‌شده", 0xFF2B3470.toInt()) {
            val selected = MacroStore.steps.getOrNull(MacroStore.selectedIndex())
            if (selected != null && !selected.isDelay) {
                MacroStore.selectStart(selected.id)
                requestReplacement(selected.id)
            }
            else showMessage("ابتدا یک تصویر را انتخاب کنید")
        }
        val collapse = iconButton("−", "بستن پنل شناور", 0xFF2B3470.toInt()) { toggleFloatingMenu() }
        header.addView(title, LinearLayout.LayoutParams(0, dp(26), 1f))
        header.addView(settings, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(2) })
        header.addView(replace, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(2) })
        header.addView(collapse, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(2) })

        val record = actionButton("●", "ضبط", "شروع یا پایان ضبط لمس‌ها", 0xFF30367A.toInt()) {
            setRecording(!recording)
        }
        val play = actionButton("▶", "اجرا", "شروع یا ادامهٔ ماکرو", 0xFF5338D8.toInt()) {
            if (!ScreenCaptureService.hasFrame()) showMessage("اول اشتراک‌گذاری صفحه را فعال کنید")
            else if (MacroStore.selectedIndex() < 0) showMessage("اول از فهرست یک تصویر انتخاب کنید")
            else {
                MacroRunner.start(MacroStore.selectedIndex(), repeatCount = MacroStore.repeatCount)
            }
        }
        val pause = actionButton("Ⅱ", "مکث", "مکث ماکرو", 0xFF3A3F66.toInt()) {
            MacroRunner.pause()
        }
        val stop = actionButton("■", "توقف", "توقف ماکرو", 0xFF8A2D4E.toInt()) {
            MacroRunner.stop()
        }
        val previous = actionButton("‹", "قبلی", "انتخاب اکشن قبلی", 0xFF2B3470.toInt()) { selectRelativeStep(-1) }
        val next = actionButton("›", "بعدی", "انتخاب اکشن بعدی", 0xFF2B3470.toInt()) { selectRelativeStep(1) }
        fun addActionRow(first: TextView, second: TextView) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            listOf(first, second).forEach { button ->
                row.addView(button, LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                    marginStart = dp(2)
                    marginEnd = dp(2)
                })
            }
            panel.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(41)).apply { topMargin = dp(1) })
        }
        addActionRow(record, play)
        addActionRow(pause, stop)
        addActionRow(previous, next)
        val status = TextView(this).apply {
            textSize = 8.5f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(0xFFC3CAD2.toInt())
            setPadding(dp(5), 0, dp(5), 0)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            background = rounded(0xFF0D1116.toInt(), 0xFF252B33.toInt(), 10)
        }
        panel.addView(header, 0)
        panel.addView(status, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(31)).apply { topMargin = dp(2) })
        scriptLabel = title
        recordButton = record
        playButton = play
        pauseButton = pause
        stopButton = stop
        previousButton = previous
        nextButton = next
        floatingStatus = status

        val mini = TextView(this).apply {
            text = "☰"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 0)
            setTextColor(Color.rgb(6, 24, 33))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8E7BFF.toInt(), 0xFF3DD6FF.toInt())).apply { cornerRadius = dp(24).toFloat() }
            contentDescription = AppLanguage.translate("باز کردن کنترل‌های ماکرو")
            elevation = dp(5).toFloat()
        }
        bubble = mini
        floatingPanel = panel
        floatingRoot = root
        root.addView(panel)
        root.addView(mini, LinearLayout.LayoutParams(dp(48), dp(30)).apply { topMargin = dp(1) })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            x = dp(4)
        }
        floatingParams = params
        try {
            manager.addView(root, params)
            root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateFloatingBounds() }
            mini.setOnTouchListener(makeBubbleTouchListener(manager))
            refreshFloatingMenu()
            updateFloatingBounds()
        } catch (_: WindowManager.BadTokenException) {
            floatingRoot = null
            MacroStore.status = "منوی شناور توسط اندروید نمایش داده نشد"
        }
    }

    private fun makeBubbleTouchListener(manager: WindowManager) = View.OnTouchListener { view, event ->
        val params = floatingParams ?: return@OnTouchListener false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragStartX = event.rawX
                dragStartY = event.rawY
                dragWindowX = params.x
                dragWindowY = params.y
                draggingBubble = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - dragStartX).roundToInt()
                val dy = (event.rawY - dragStartY).roundToInt()
                val slop = ViewConfiguration.get(this).scaledTouchSlop
                if (abs(dx) > slop || abs(dy) > slop) draggingBubble = true
                if (draggingBubble) {
                    params.x = (dragWindowX - dx).coerceAtLeast(0)
                    params.y = dragWindowY + dy
                    floatingRoot?.let { root -> runCatching { manager.updateViewLayout(root, params) } }
                }
                true
            }
            MotionEvent.ACTION_UP -> {
                if (!draggingBubble) { markControlTouch(view); toggleFloatingMenu() }
                true
            }
            else -> true
        }
    }

    private fun iconButton(icon: String, description: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = icon
        textSize = 19f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(color, 0xFF343D48.toInt(), 11)
        contentDescription = AppLanguage.translate(description)
        isClickable = true
        isFocusable = false
        pressEffect()
        setOnClickListener {
            markControlTouch(this)
            Handler(mainLooper).postDelayed({
                onClick()
                refreshFloatingMenu()
            }, 120L)
        }
    }

    private fun actionButton(icon: String, label: String, description: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = actionLabel(icon, AppLanguage.translate(label))
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(color, 0xFF465566.toInt(), 11)
        contentDescription = AppLanguage.translate(description)
        isClickable = true
        pressEffect()
        setOnClickListener {
            markControlTouch(this)
            Handler(mainLooper).postDelayed({
                onClick()
                refreshFloatingMenu()
            }, 120L)
        }
    }

    private fun actionLabel(icon: String, label: String) = SpannableStringBuilder("$icon\n${AppLanguage.translate(label)}").apply {
        setSpan(RelativeSizeSpan(0.65f), icon.length + 1, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun lighten(color: Int, factor: Float): Int = Color.argb(
        Color.alpha(color),
        (Color.red(color) * factor).toInt().coerceAtMost(255),
        (Color.green(color) * factor).toInt().coerceAtMost(255),
        (Color.blue(color) * factor).toInt().coerceAtMost(255)
    )

    private fun rounded(color: Int, stroke: Int, radiusDp: Int) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(lighten(color, 1.4f), color)
    ).apply {
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), stroke)
    }

    /** افکت فشرده‌شدن سه‌بعدی برای دکمه‌های منوی شناور */
    private fun View.pressEffect() {
        setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.9f).scaleY(0.9f).translationZ(-dp(3).toFloat()).setDuration(70L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(120L).start()
            }
            false
        }
    }

    private fun toggleFloatingMenu() {
        expanded = !expanded
        floatingPanel?.let { panel ->
            panel.animate().cancel()
            panel.cameraDistance = 9000f * resources.displayMetrics.density
            panel.pivotX = (panel.layoutParams?.width?.takeIf { it > 0 } ?: dp(132)).toFloat()
            panel.pivotY = 0f
            if (expanded) {
                panel.visibility = View.VISIBLE
                panel.alpha = 0f
                panel.scaleX = 0.82f
                panel.scaleY = 0.82f
                panel.rotationY = -38f
                panel.animate().alpha(1f).scaleX(1f).scaleY(1f).rotationY(0f).setDuration(240L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.05f)).start()
            } else {
                panel.animate().alpha(0f).scaleX(0.86f).scaleY(0.86f).rotationY(-28f).setDuration(150L).withEndAction {
                    panel.visibility = View.GONE
                    panel.alpha = 1f; panel.scaleX = 1f; panel.scaleY = 1f; panel.rotationY = 0f
                    updateFloatingBounds()
                }.start()
            }
        }
        bubble?.contentDescription = AppLanguage.translate(if (expanded) "بستن منوی ماکرو" else "باز کردن کنترل‌های ماکرو")
        updateFloatingBounds()
    }

    fun refreshFloatingMenu() {
        settingsOverlay?.refreshRecording(recording)
        recordButton?.text = actionLabel(if (recording) "■" else "●", if (recording) "پایان" else "ضبط")
        recordButton?.contentDescription = AppLanguage.translate(if (recording) "توقف ضبط" else "شروع ضبط")
        recordButton?.background = rounded(if (recording) 0xFFB0304F.toInt() else 0xFF30367A.toInt(), 0xFF7B88FF.toInt(), 11)
        playButton?.text = actionLabel("▶", if (MacroRunner.isPaused) "ادامه" else "اجرا")
        pauseButton?.text = actionLabel("Ⅱ", "مکث")
        stopButton?.text = actionLabel("■", "توقف")
        previousButton?.text = actionLabel("‹", "قبلی")
        nextButton?.text = actionLabel("›", "بعدی")
        playButton?.alpha = if (MacroRunner.isRunning && !MacroRunner.isPaused) 0.55f else 1f
        pauseButton?.alpha = if (MacroRunner.isRunning && !MacroRunner.isPaused) 1f else 0.55f
        stopButton?.alpha = if (MacroRunner.isRunning) 1f else 0.55f
        scriptLabel?.text = AppLanguage.translate(MacroStore.scriptName)
        val state = when {
            recording -> "در حال ضبط"
            MacroRunner.isPaused -> "مکث شده"
            MacroRunner.isRunning -> "در حال اجرا"
            else -> "آماده"
        }
        val position = MacroStore.selectedIndex().let { if (it >= 0) it + 1 else 0 }
        floatingStatus?.text = AppLanguage.translate("وضعیت: $state · مرحله $position/${MacroStore.steps.size}\n${MacroStore.status}")
        bubble?.apply {
            val busy = recording || MacroRunner.isRunning
            if (busy && bubblePulse == null) {
                bubblePulse = android.animation.ObjectAnimator.ofPropertyValuesHolder(
                    this,
                    android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.14f),
                    android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.14f)
                ).apply {
                    duration = 650L
                    repeatCount = android.animation.ValueAnimator.INFINITE
                    repeatMode = android.animation.ValueAnimator.REVERSE
                    start()
                }
            } else if (!busy && bubblePulse != null) {
                bubblePulse?.cancel()
                bubblePulse = null
                scaleX = 1f
                scaleY = 1f
            }
            text = when {
                recording -> "●"
                MacroRunner.isPaused -> "Ⅱ"
                MacroRunner.isRunning -> "▶"
                else -> "☰"
            }
            contentDescription = AppLanguage.translate(if (expanded) "بستن پنل شناور" else when {
                recording -> "ضبط در جریان؛ باز کردن کنترل‌ها"
                MacroRunner.isPaused -> "ماکرو مکث شده؛ باز کردن کنترل‌ها"
                MacroRunner.isRunning -> "ماکرو در حال اجرا؛ باز کردن کنترل‌ها"
                else -> "باز کردن کنترل‌های ماکرو"
            })
            background = if (recording) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF8791.toInt(), 0xFFFFC071.toInt())).apply { cornerRadius = dp(24).toFloat() }
            } else {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8E7BFF.toInt(), 0xFF3DD6FF.toInt())).apply { cornerRadius = dp(24).toFloat() }
            }
        }
    }

    fun requestReplacement(stepId: Long) {
        if (replacementStepId == stepId && cropOverlay?.isShowing() == true) return
        if (MacroStore.steps.none { it.id == stepId && !it.isDelay }) {
            showMessage("ابتدا یک تصویر را انتخاب کنید")
            return
        }
        if (recording) setRecording(false)
        closeSettingsOverlay()
        closeCropOverlay()
        replacementStepId = stepId
        val frame = ScreenCaptureService.latestFrame()
        if (frame == null) {
            MacroStore.status = "فریم تازه نرسیده؛ اشتراک‌گذاری صفحه را بررسی کنید"
            refreshFloatingMenu()
            return
        }
        val width = frame.width
        val height = frame.height
        frame.recycle()
        MacroStore.status = "کادر جایگزینی باز شد؛ ناحیه را روی تصویر انتخاب کنید"
        showMessage("کادر جایگزینی باز شد")
        expanded = false
        floatingPanel?.visibility = View.GONE
        cropOverlay = LiveCropOverlay(
            this,
            width,
            height,
            MacroStore.patchWidth,
            MacroStore.patchHeight,
            onSave = { selection -> saveReplacementFrame(stepId, selection) },
            onCancel = {
                closeCropOverlay()
                replacementStepId = null
                refreshFloatingMenu()
            }
        ).also(LiveCropOverlay::show)
        updateFloatingBounds()
    }

    private fun saveReplacementFrame(stepId: Long, selection: LiveCropSelection) {
        if (replacementStepId != stepId) return
        replacementStepId = null
        closeCropOverlay()
        Handler(mainLooper).postDelayed({
            val frame = ScreenCaptureService.latestFrame()
            if (frame == null) {
                MacroStore.status = "فریم تازه نرسیده؛ اشتراک‌گذاری صفحه را بررسی کنید"
            } else {
                val scaleX = frame.width.toFloat() / selection.frameWidth
                val scaleY = frame.height.toFloat() / selection.frameHeight
                MacroStore.replace(
                    stepId,
                    frame,
                    selection.centerX * scaleX,
                    selection.centerY * scaleY,
                    selection.boxWidth * scaleX,
                    selection.boxHeight * scaleY,
                    selection.pointX * scaleX,
                    selection.pointY * scaleY
                )
                frame.recycle()
                MacroStore.status = "تصویر زنده جایگزین شد"
            }
            refreshFloatingMenu()
        }, 180L)
    }

    private fun showSettingsOverlay() {
        closeCropOverlay()
        settingsOverlay?.dismiss()
        if (recording) {
            recordingGeneration++
            setTouchRelayEnabled(false)
        }
        settingsOverlay = FloatingSettingsOverlay(
            this,
            onClose = { closeSettingsOverlay() },
            onRecord = { setRecording(!recording) },
            onAddTarget = {
                closeSettingsOverlay()
                Handler(mainLooper).postDelayed({
                    val frame = ScreenCaptureService.latestFrame()
                    if (frame == null) MacroStore.status = "فریم زنده آماده نیست؛ اشتراک‌گذاری صفحه را بررسی کنید"
                    else {
                        MacroStore.addTarget(frame, frame.width / 2f, frame.height / 2f)
                        frame.recycle()
                    }
                    refreshFloatingMenu()
                }, 180L)
            },
            onAddDelay = { duration ->
                MacroStore.addDelay(MacroStore.selectedIndex(), duration)
                settingsOverlay?.refreshSteps()
            },
            onReplace = { step -> requestReplacement(step.id) },
            onTest = { step, click -> testOverlayTarget(step, click) }
        ).also {
            it.show()
            it.refreshRecording(recording)
        }
    }

    private fun testOverlayTarget(step: MacroStep, click: Boolean) {
        closeSettingsOverlay()
        Handler(mainLooper).postDelayed({
            val template = MacroStore.image(step)
            if (template == null) {
                MacroStore.status = "اسکرین‌شات آماده نیست؛ مجوز صفحه را بررسی کنید"
                refreshFloatingMenu()
                return@postDelayed
            }
            val threshold = MacroStore.matchThreshold
            Thread {
                val frame = ScreenCaptureService.freshFrameSnapshot()?.bitmap
                if (frame == null) {
                    template.recycle()
                    Handler(mainLooper).post {
                        MacroStore.status = "فریم تازه دریافت نشد؛ اشتراک‌گذاری صفحه را بررسی کنید"
                        refreshFloatingMenu()
                    }
                    return@Thread
                }
                val match = runCatching { ImageMatcher.find(frame, template, grayscaleTemplate = step.grayscale) }.getOrNull()
                frame.recycle()
                template.recycle()
                Handler(mainLooper).post {
                    MacroStore.lastMatch = match?.score
                    when {
                        match == null -> MacroStore.status = "تصویر فعلی برای مقایسه در دسترس نیست"
                        click && match.score >= threshold -> {
                            tap(match.x + step.tapX * match.scaleX, match.y + step.tapY * match.scaleY)
                            MacroStore.status = "تطبیق ${match.score.toInt()}٪؛ لمس ارسال شد"
                        }
                        else -> MacroStore.status = "تطبیق تصویر: ${match.score.toInt()}٪"
                    }
                    refreshFloatingMenu()
                }
            }.start()
        }, 180L)
    }

    private fun closeSettingsOverlay() {
        val wasOpen = settingsOverlay != null
        settingsOverlay?.dismiss()
        settingsOverlay = null
        if (wasOpen && recording) scheduleRecordingTouchArm()
    }

    private fun closeCropOverlay() {
        cropOverlay?.dismiss()
        cropOverlay = null
    }

    private fun selectRelativeStep(delta: Int) {
        val imageIndices = MacroStore.steps.indices.filter { !MacroStore.steps[it].isDelay }
        if (imageIndices.isEmpty()) return
        val current = MacroStore.steps.indexOfFirst { it.id == MacroStore.selectedStepId }
        val position = imageIndices.indexOf(current).let { if (it < 0) 0 else it }
        val next = imageIndices[(position + delta).mod(imageIndices.size)]
        MacroStore.selectStart(MacroStore.steps[next].id)
        refreshFloatingMenu()
    }

    fun setRecording(enabled: Boolean): Boolean {
        if (enabled) {
            val targetPackage = resolveRecordingTarget()
            if (targetPackage == null) {
                MacroStore.status = "برنامهٔ مقصد را باز کنید و ضبط را از روی آن شروع کنید"
                showMessage("ابتدا برنامهٔ موردنظر را باز کنید")
                return false
            }
            val frame = ScreenCaptureService.latestFrame()
            if (frame == null) {
                MacroStore.status = "تصویر صفحه نرسیده؛ ابتدا اشتراک‌گذاری را فعال کنید"
                showMessage("منتظر تصویر صفحه بمانید")
                return false
            }
            frame.recycle()
            if (!setTouchRelayEnabled(false)) {
                MacroStore.status = "لایهٔ ثبت لمس آماده نیست؛ Accessibility را دوباره روشن کنید"
                return false
            }
            clearTouchSequence()
            MacroStore.beginRecording()
            recordingTargetPackage = targetPackage
            recording = true
            MacroStore.status = if (settingsOverlay != null) {
                "ضبط آماده است؛ برای ثبت لمس‌های بازی پنجره را ببندید"
            } else "ضبط روشن می‌شود؛ لمس دکمهٔ شروع ثبت نمی‌شود"
            showMessage("ضبط لمس روشن شد")
            if (settingsOverlay == null) scheduleRecordingTouchArm()
        } else {
            recordingGeneration++
            recording = false
            recordingTargetPackage = null
            setTouchRelayEnabled(false)
            clearTouchSequence()
            MacroStore.status = "ضبط متوقف شد"
            showMessage("ضبط لمس متوقف شد")
        }
        refreshFloatingMenu()
        return true
    }

    private fun scheduleRecordingTouchArm() {
        if (!recording || settingsOverlay != null) return
        val generation = ++recordingGeneration
        setTouchRelayEnabled(false)
        Handler(mainLooper).postDelayed({
            if (!recording || generation != recordingGeneration || settingsOverlay != null) return@postDelayed
            if (setTouchRelayEnabled(true)) {
                MacroStore.status = "ضبط روشن است؛ فقط لمس‌های برنامهٔ مقصد ثبت می‌شود"
            } else {
                recording = false
                recordingTargetPackage = null
                recordingGeneration++
                setTouchRelayEnabled(false)
                MacroStore.status = "لایهٔ ثبت لمس آماده نیست؛ Accessibility را دوباره روشن کنید"
                showMessage("لایهٔ ثبت لمس آماده نیست")
            }
            refreshFloatingMenu()
        }, RECORD_ARM_DELAY_MS)
    }

    private fun setTouchRelayEnabled(enabled: Boolean): Boolean {
        val relay = touchRelay ?: return false
        val params = touchRelayParams ?: return false
        val flags = if (enabled) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        if (flags == params.flags) return true
        params.flags = flags
        return try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(relay, params)
            true
        } catch (_: WindowManager.BadTokenException) {
            false
        }
    }

    private fun setFloatingTouchEnabled(enabled: Boolean) {
        val root = floatingRoot ?: return
        val params = floatingParams ?: return
        val flags = if (enabled) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        if (flags == params.flags) return
        params.flags = flags
        runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(root, params) }
    }

    private fun clampToActiveWindow(x: Float, y: Float): Pair<Float, Float> {
        val bounds = Rect()
        val activeWindow = runCatching {
            windows.firstOrNull {
                it.isActive && it.type != android.view.accessibility.AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY
            }?.also { it.getBoundsInScreen(bounds) }
        }.getOrNull() ?: return x to y
        if (bounds.isEmpty) return x to y
        val inset = dp(2).toFloat()
        return x.coerceIn(bounds.left + inset, (bounds.right - inset).coerceAtLeast(bounds.left.toFloat())) to
            y.coerceIn(bounds.top + inset, (bounds.bottom - inset).coerceAtLeast(bounds.top.toFloat()))
    }

    private fun updateFloatingBounds() {
        val root = floatingRoot ?: return
        val location = IntArray(2)
        root.getLocationOnScreen(location)
        floatingBounds.set(location[0], location[1], location[0] + root.width, location[1] + root.height)
    }

    private fun systemDimension(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id != 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun isCaptureTarget(packageName: String): Boolean {
        if (packageName == this.packageName) return false
        return packageName != "com.android.systemui" &&
            packageName != "com.android.settings" &&
            !packageName.contains("permissioncontroller", ignoreCase = true) &&
            !packageName.contains("launcher", ignoreCase = true) &&
            !packageName.contains("setupwizard", ignoreCase = true)
    }

    private fun activeWindowPackage(): String? = runCatching {
        windows.firstOrNull { it.isActive && it.type != android.view.accessibility.AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY }
            ?.root?.let { root -> root.packageName?.toString().also { root.recycle() } }
    }.getOrNull() ?: runCatching {
        rootInActiveWindow?.let { root -> root.packageName?.toString().also { root.recycle() } }
    }.getOrNull()

    private fun resolveRecordingTarget(): String? {
        val activePackage = activeWindowPackage()
        return activePackage?.takeIf(::isCaptureTarget)
            ?: foregroundPackage?.takeIf(::isCaptureTarget)
    }

    private fun isRecordingTargetForeground(): Boolean {
        val target = recordingTargetPackage ?: return false
        val activePackage = activeWindowPackage() ?: foregroundPackage
        return activePackage == target
    }

    private fun markControlTouch(view: View) {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        recentControlBounds.set(location[0] - dp(8), location[1] - dp(8), location[0] + view.width + dp(8), location[1] + view.height + dp(8))
        recentControlTime = SystemClock.uptimeMillis()
    }

    private fun isFloatingControlTouch(event: MotionEvent): Boolean {
        updateFloatingBounds()
        val x = event.rawX.roundToInt()
        val y = event.rawY.roundToInt()
        val recentControlTap = event.eventTime - recentControlTime in 0L..900L && recentControlBounds.contains(x, y)
        return floatingBounds.contains(x, y) || recentControlTap
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        if (isCaptureTarget(packageName)) foregroundPackage = packageName
    }

    private fun handleRelayTouch(view: View, event: MotionEvent): Boolean {
        if (!recording) return false
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            touchSequenceBlockedByReplay = replayingTouch ||
                (event.eventTime <= replayTouchGuardUntil && isReplayedTouch(event.rawX, event.rawY))
        }
        if (touchSequenceBlockedByReplay) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                touchSequenceBlockedByReplay = false
            }
            return true
        }
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            touchSequenceBlockedByUi = isFloatingControlTouch(event)
        }
        if (touchSequenceBlockedByUi || isFloatingControlTouch(event)) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                touchSequenceBlockedByUi = false
            }
            return true
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (event.downTime == lastTouchDownTime) return true
                lastTouchDownTime = event.downTime
                touchStrokes.clear()
                activeTouchPointers.clear()
                touchSequenceStart = event.eventTime
                touchStartX = event.rawX
                touchStartY = event.rawY
                touchDownAt = event.eventTime
                touchMoved = false
                touchHadMultiplePointers = false
                touchSequenceBelongsToTarget = isRecordingTargetForeground() ||
                    (isNavigationBarTouch(event.rawX, event.rawY) && foregroundPackage == recordingTargetPackage)
                startTouchStroke(view, event, event.actionIndex)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                appendActiveTouchPoints(view, event)
                touchHadMultiplePointers = true
                startTouchStroke(view, event, event.actionIndex)
            }
            MotionEvent.ACTION_MOVE -> {
                appendActiveTouchPoints(view, event)
                if (abs(event.rawX - touchStartX) > 24f || abs(event.rawY - touchStartY) > 24f) touchMoved = true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                finishTouchStroke(view, event, event.actionIndex)
                touchHadMultiplePointers = true
            }
            MotionEvent.ACTION_UP -> {
                if (touchDownAt == 0L) return true
                finishTouchStroke(view, event, event.actionIndex)
                val held = if (touchDownAt == 0L) 0L else event.eventTime - touchDownAt
                val gesture = buildTouchGesture()
                val replayPoint = touchStartX to touchStartY
                if (touchSequenceBelongsToTarget && !touchHadMultiplePointers && !touchMoved && held <= 650L) {
                    recordAt(touchStartX, touchStartY, event.downTime)
                }
                clearTouchSequence()
                if (gesture != null) dispatchReplayedGesture(gesture, replayPoint = replayPoint)
            }
            MotionEvent.ACTION_CANCEL -> {
                touchSequenceBlockedByUi = false
                clearTouchSequence()
            }
        }
        return true
    }

    private fun startTouchStroke(view: View, event: MotionEvent, pointerIndex: Int) {
        val (x, y) = screenPoint(view, event, pointerIndex)
        val id = event.getPointerId(pointerIndex)
        val start = (event.eventTime - touchSequenceStart).coerceAtLeast(0L)
        touchStrokes[id] = TouchStroke(Path().apply { moveTo(x, y) }, start, start + 1L)
        activeTouchPointers.add(id)
    }

    private fun appendActiveTouchPoints(view: View, event: MotionEvent) {
        for (index in 0 until event.pointerCount) {
            val id = event.getPointerId(index)
            if (id !in activeTouchPointers) continue
            val (x, y) = screenPoint(view, event, index)
            touchStrokes[id]?.path?.lineTo(x, y)
        }
    }

    private fun finishTouchStroke(view: View, event: MotionEvent, pointerIndex: Int) {
        appendActiveTouchPoints(view, event)
        val id = event.getPointerId(pointerIndex)
        touchStrokes[id]?.endMs = (event.eventTime - touchSequenceStart).coerceAtLeast((touchStrokes[id]?.startMs ?: 0L) + 1L)
        activeTouchPointers.remove(id)
    }

    private fun screenPoint(view: View, event: MotionEvent, pointerIndex: Int): Pair<Float, Float> {
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        return (location[0] + event.getX(pointerIndex)) to (location[1] + event.getY(pointerIndex))
    }

    private fun buildTouchGesture(): GestureDescription? {
        if (touchStrokes.isEmpty()) return null
        val builder = GestureDescription.Builder()
        touchStrokes.values.forEach { stroke ->
            val start = stroke.startMs.coerceAtMost(59_999L)
            val duration = (stroke.endMs - stroke.startMs).coerceIn(60L, 60_000L)
            builder.addStroke(GestureDescription.StrokeDescription(stroke.path, start, duration))
        }
        return runCatching { builder.build() }.getOrNull()
    }

    private fun clearTouchSequence() {
        touchDownAt = 0L
        touchSequenceStart = 0L
        touchHadMultiplePointers = false
        touchSequenceBelongsToTarget = false
        touchStrokes.clear()
        activeTouchPointers.clear()
    }

    private fun dispatchReplayedGesture(
        gesture: GestureDescription,
        onComplete: (() -> Unit)? = null,
        replayPoint: Pair<Float, Float>? = null
    ) {
        val restoreTouch = recording
        val floatingWasTouchable = floatingParams?.flags?.and(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0
        if (floatingWasTouchable) setFloatingTouchEnabled(false)
        if (restoreTouch) {
            replayingTouch = true
            replayPoint?.let { (x, y) ->
                replayTouchX = x
                replayTouchY = y
                replayTouchGuardUntil = Long.MAX_VALUE
            }
        }
        if (restoreTouch && !setTouchRelayEnabled(false)) {
            replayingTouch = false
            replayTouchGuardUntil = 0L
            if (floatingWasTouchable) setFloatingTouchEnabled(true)
            MacroStore.status = "لمس دریافت شد اما به برنامهٔ زیرین فرستاده نشد"
            onComplete?.invoke()
            return
        }
        var finished = false
        fun finish() {
            if (finished) return
            finished = true
            if (restoreTouch) {
                replayingTouch = false
                replayTouchGuardUntil = SystemClock.uptimeMillis() + REPLAY_TOUCH_GUARD_MS
            }
            if (restoreTouch && recording) setTouchRelayEnabled(true)
            if (floatingWasTouchable) setFloatingTouchEnabled(true)
            onComplete?.invoke()
        }
        Handler(mainLooper).postDelayed({
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (restoreTouch) MacroStore.status = "لمس ضبط شد و به بازی فرستاده شد"
                    finish()
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    MacroStore.status = "اندروید لمس را لغو کرد"
                    finish()
                }
            }, null)
            if (!accepted) {
                MacroStore.status = "اندروید لمس را نپذیرفت"
                finish()
            }
        }, REPLAY_DISPATCH_DELAY_MS)
    }

    private fun recordAt(x: Float, y: Float, downTime: Long) {
        if (downTime == lastRecordedTouchDownTime) return
        lastRecordedTouchDownTime = downTime
        val frame = ScreenCaptureService.latestFrame()
        if (frame == null) {
            MacroStore.status = "لمس دیده شد اما اسکرین‌شات آماده نیست"
            return
        }
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val frameX = x * frame.width / metrics.widthPixels.coerceAtLeast(1)
        val frameY = y * frame.height / metrics.heightPixels.coerceAtLeast(1)
        MacroStore.recordTap(frame, frameX, frameY)
        frame.recycle()
    }

    private fun isNavigationBarTouch(x: Float, y: Float): Boolean {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val bottom = y >= metrics.heightPixels - systemDimension("navigation_bar_height")
        val sideWidth = systemDimension("navigation_bar_width")
        val landscapeSide = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE &&
            (x < sideWidth || x >= metrics.widthPixels - sideWidth)
        return bottom || landscapeSide
    }

    private fun isReplayedTouch(x: Float, y: Float) =
        abs(x - replayTouchX) < dp(8) && abs(y - replayTouchY) < dp(8)

    private fun showMessage(message: String) {
        Toast.makeText(this, AppLanguage.translate(message), Toast.LENGTH_SHORT).show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    override fun onInterrupt() { setRecording(false) }

    override fun onDestroy() {
        recording = false
        bubblePulse?.cancel()
        bubblePulse = null
        closeSettingsOverlay()
        closeCropOverlay()
        try { touchRelay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) { }
        try { floatingRoot?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) { }
        touchRelay = null
        floatingRoot = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun tap(x: Float, y: Float, durationMs: Long = 60L, onComplete: (() -> Unit)? = null) {
        val (targetX, targetY) = clampToActiveWindow(x, y)
        val path = Path().apply { moveTo(targetX, targetY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
            .build()
        dispatchReplayedGesture(gesture, onComplete, targetX to targetY)
    }

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
        var recording by mutableStateOf(false)
        private var dragStartX = 0f
        private var dragStartY = 0f
        private var dragWindowX = 0
        private var dragWindowY = 0
        private var draggingBubble = false
        private const val RECORD_ARM_DELAY_MS = 450L
        private const val REPLAY_TOUCH_GUARD_MS = 220L
        private const val REPLAY_DISPATCH_DELAY_MS = 80L
    }
}
