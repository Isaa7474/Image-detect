package app.imagedetect

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val NeoViolet = Color(0xFF7C5CFF)
val NeoIndigo = Color(0xFF4B2FD6)
val NeoCyan = Color(0xFF3DD6FF)
val NeoBlueDeep = Color(0xFF1B6EE0)
val NeoRed = Color(0xFFFF5A7A)
val NeoRedDeep = Color(0xFFB3263E)
val NeoSteel = Color(0xFF4A5170)
val NeoSteelDeep = Color(0xFF2A2F47)

/** پس‌زمینهٔ متحرک با کف شبکه‌ای پرسپکتیو و گوی‌های نورانی شناور. */
@Composable
fun SpaceBackground(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "bg")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "grid"
    )
    val drift by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse), label = "drift"
    )
    Canvas(modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF050814), Color(0xFF120A2E), Color(0xFF08142B))))
        val w = size.width
        val h = size.height
        val orbA = Offset(w * (0.15f + 0.35f * drift), h * 0.16f)
        drawCircle(Brush.radialGradient(listOf(Color(0x557C5CFF), Color.Transparent), center = orbA, radius = w * 0.65f), radius = w * 0.65f, center = orbA)
        val orbB = Offset(w * (0.9f - 0.4f * drift), h * 0.42f)
        drawCircle(Brush.radialGradient(listOf(Color(0x443DD6FF), Color.Transparent), center = orbB, radius = w * 0.6f), radius = w * 0.6f, center = orbB)
        val horizon = h * 0.64f
        val vanishing = Offset(w / 2f, horizon)
        for (i in 0..9) {
            val t = (i + phase) / 10f
            val y = horizon + (h - horizon) * t * t
            drawLine(NeoCyan.copy(alpha = 0.04f + 0.22f * t), Offset(0f, y), Offset(w, y), strokeWidth = 1.4f)
        }
        for (i in -8..8) {
            val bottomX = w / 2f + i * (w / 5f)
            drawLine(NeoViolet.copy(alpha = 0.28f), vanishing, Offset(bottomX, h), strokeWidth = 1.2f)
        }
    }
}

/** کارت قهرمان سه‌بعدی: مکعب سیمی چرخان، پرتو اسکن و حلقهٔ درصد تطبیق. با لمس، کارت در فضا کج می‌شود. */
@Composable
fun ScanHero3D(label: String, status: String, score: Float?, active: Boolean, modifier: Modifier = Modifier) {
    var tiltX by remember { mutableFloatStateOf(0f) }
    var tiltY by remember { mutableFloatStateOf(0f) }
    val animX by animateFloatAsState(tiltX, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow), label = "tiltX")
    val animY by animateFloatAsState(tiltY, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow), label = "tiltY")
    val transition = rememberInfiniteTransition(label = "hero")
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin"
    )
    val sweep by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "sweep"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.85f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "pulse"
    )
    val shape = RoundedCornerShape(26.dp)
    val accent = if (active) NeoRed else NeoCyan
    Box(
        modifier
            .fillMaxWidth()
            .height(236.dp)
            .graphicsLayer {
                rotationX = animX
                rotationY = animY
                cameraDistance = 14f * density
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull()
                        if (pointer == null || !pointer.pressed) {
                            tiltX = 0f; tiltY = 0f
                        } else {
                            val nx = (pointer.position.x / size.width.coerceAtLeast(1) - 0.5f) * 2f
                            val ny = (pointer.position.y / size.height.coerceAtLeast(1) - 0.5f) * 2f
                            tiltY = (nx * 16f).coerceIn(-16f, 16f)
                            tiltX = (-ny * 16f).coerceIn(-16f, 16f)
                        }
                    }
                }
            }
            .shadow(22.dp, shape, ambientColor = NeoViolet, spotColor = accent)
            .background(Brush.linearGradient(listOf(Color(0xE61C1F4A), Color(0xE60C1230))), shape)
            .border(1.2.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.9f), NeoViolet.copy(alpha = 0.35f))), shape)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width * 0.74f
            val cy = size.height * 0.5f
            val unit = size.height * 0.2f
            // حلقهٔ درصد تطبیق
            val ringRadius = unit * 2.05f
            val ringTopLeft = Offset(cx - ringRadius, cy - ringRadius)
            val ringSize = Size(ringRadius * 2f, ringRadius * 2f)
            drawArc(Color.White.copy(alpha = 0.08f), 0f, 360f, false, ringTopLeft, ringSize, style = Stroke(7f))
            val shown = (score ?: 0f).coerceIn(0f, 100f)
            if (shown > 0f) {
                drawArc(
                    Brush.sweepGradient(listOf(NeoViolet, accent, NeoViolet), Offset(cx, cy)),
                    -90f, 360f * shown / 100f, false, ringTopLeft, ringSize, style = Stroke(9f, cap = StrokeCap.Round)
                )
            }
            // مکعب‌های سیمی چرخان (تو در تو)
            fun cube(size3: Float, angleDeg: Float, tilt: Float, color: Color, width: Float) {
                val ay = Math.toRadians(angleDeg.toDouble())
                val ax = Math.toRadians(tilt.toDouble())
                val points = Array(8) { i ->
                    val x0 = if (i and 1 == 0) -1f else 1f
                    val y0 = if (i and 2 == 0) -1f else 1f
                    val z0 = if (i and 4 == 0) -1f else 1f
                    val x1 = (x0 * cos(ay) + z0 * sin(ay)).toFloat()
                    val z1 = (-x0 * sin(ay) + z0 * cos(ay)).toFloat()
                    val y2 = (y0 * cos(ax) - z1 * sin(ax)).toFloat()
                    val z2 = (y0 * sin(ax) + z1 * cos(ax)).toFloat()
                    val perspective = 4f / (4f + z2)
                    floatArrayOf(cx + x1 * perspective * size3, cy + y2 * perspective * size3, z2)
                }
                for (i in 0 until 8) for (bit in intArrayOf(1, 2, 4)) {
                    val j = i xor bit
                    if (j > i) {
                        val depth = ((points[i][2] + points[j][2]) / 2f + 1.5f) / 3f
                        drawLine(
                            color.copy(alpha = (0.35f + 0.65f * depth).coerceIn(0.2f, 1f)),
                            Offset(points[i][0], points[i][1]), Offset(points[j][0], points[j][1]),
                            strokeWidth = width, cap = StrokeCap.Round
                        )
                    }
                }
            }
            cube(unit * 1.15f, spin, 28f, accent, 3.2f)
            cube(unit * 0.55f * (if (active) pulse else 1f), -spin * 1.7f, 28f, NeoViolet, 2.4f)
            // پرتو اسکن
            val scanY = size.height * sweep
            drawLine(
                Brush.horizontalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.85f), Color.Transparent)),
                Offset(0f, scanY), Offset(size.width, scanY), strokeWidth = 3f
            )
        }
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
            Text("IMAGE DETECT", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(AppLanguage.translate(label), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            if (score != null) Text("${score.toInt()}٪", color = accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.weight(1f))
            Text(
                AppLanguage.translate(status), color = Color(0xFFC9CFEA), fontSize = 11.sp, lineHeight = 16.sp,
                maxLines = 3, textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth(0.58f)
            )
        }
    }
}

/** دکمهٔ سه‌بعدی با ضخامت واقعی، گرادیان و حالت فشرده‌شدن. */
@Composable
fun Button3D(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    top: Color = NeoViolet,
    bottom: Color = NeoIndigo,
    enabled: Boolean = true,
    height: Dp = 52.dp,
    fontSize: Int = 13
) {
    var pressed by remember { mutableStateOf(false) }
    val depth = 6.dp
    val faceOffset by animateDpAsState(if (pressed && enabled) depth else 0.dp, tween(70), label = "press")
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(15.dp)
    Box(
        modifier
            .height(height + depth)
            .graphicsLayer { alpha = if (enabled) 1f else 0.42f }
            .pointerInput(enabled) {
                detectTapGestures(
                    onPress = {
                        if (enabled) {
                            pressed = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            tryAwaitRelease()
                            pressed = false
                        }
                    },
                    onTap = { if (enabled) onClick() }
                )
            }
    ) {
        Box(
            Modifier.fillMaxWidth().height(height).offset(y = depth)
                .background(Color(0xFF0B0A24), shape)
        )
        Box(
            Modifier.fillMaxWidth().height(height).offset(y = faceOffset)
                .background(Brush.verticalGradient(listOf(top, bottom)), shape)
                .border(1.dp, Color.White.copy(alpha = 0.28f), shape),
            contentAlignment = Alignment.Center
        ) {
            Text(AppLanguage.translate(text), color = Color.White, fontWeight = FontWeight.Bold, fontSize = fontSize.sp, maxLines = 1)
        }
    }
}
