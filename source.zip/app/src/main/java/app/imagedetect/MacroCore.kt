package app.imagedetect

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

data class MacroStep(
    val id: Long,
    val imageName: String?,
    val delayMs: Long,
    val tapX: Float = 22.5f,
    val tapY: Float = 22.5f,
    val capturePreviewName: String? = null,
    val captureX: Float? = null,
    val captureY: Float? = null,
    val grayscale: Boolean = false
) {
    val isDelay: Boolean get() = imageName == null
}

object MacroStore {
    const val PATCH_SIZE = 60
    private const val MIN_PATCH_SIZE = 16
    private const val MAX_PATCH_SIZE = 512
    val steps = mutableStateListOf<MacroStep>()
    var status by mutableStateOf("برای شروع، مجوزهای لازم را فعال کنید")
    var lastMatch by mutableStateOf<Float?>(null)
    var patchWidth by mutableIntStateOf(PATCH_SIZE)
        private set
    var patchHeight by mutableIntStateOf(PATCH_SIZE)
        private set
    var matchThreshold by mutableFloatStateOf(78f)
        private set
    var searchTimeoutSeconds by mutableIntStateOf(15)
        private set
    var searchIntervalMs by mutableIntStateOf(120)
        private set
    var grayscaleCapture by mutableStateOf(false)
        private set
    var scriptName by mutableStateOf("اسکریپت من")
        private set
    var scriptDescription by mutableStateOf("")
        private set
    var repeatCount by mutableIntStateOf(1)
        private set
    @Volatile var selectedStepId = -1L
    private lateinit var appContext: Context
    private var lastTapAt = 0L
    private var copiedAction: MacroStep? = null
    private var copiedImageFile: File? = null
    private val lock = Any()

    fun initialize(context: Context) = synchronized(lock) {
        if (::appContext.isInitialized) return@synchronized
        appContext = context.applicationContext
        val saved = appContext.getSharedPreferences("macro", Context.MODE_PRIVATE).getString("steps", "[]")
        val prefs = appContext.getSharedPreferences("macro", Context.MODE_PRIVATE)
        runCatching {
            val array = JSONArray(saved)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                steps.add(MacroStep(item.getLong("id"), item.optString("image").takeIf(String::isNotEmpty), item.optLong("delay"), item.optDouble("x", 22.5).toFloat(), item.optDouble("y", 22.5).toFloat(), item.optString("capture").takeIf(String::isNotEmpty), item.optDouble("cx", Double.NaN).toFloat().takeUnless(Float::isNaN), item.optDouble("cy", Double.NaN).toFloat().takeUnless(Float::isNaN), item.optBoolean("gray", false)))
            }
        }
        selectedStepId = prefs.getLong("selected", -1L)
        scriptName = prefs.getString("name", "اسکریپت من") ?: "اسکریپت من"
        scriptDescription = prefs.getString("description", "") ?: ""
        repeatCount = if (prefs.contains("repeat_count")) {
            prefs.getInt("repeat_count", 1).coerceIn(0, 999_999)
        } else if (prefs.getBoolean("loop", false)) 0 else 1
        patchWidth = prefs.getInt("patch_width", PATCH_SIZE).coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        patchHeight = prefs.getInt("patch_height", PATCH_SIZE).coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        matchThreshold = prefs.getFloat("match_threshold", 78f).coerceIn(50f, 95f)
        searchTimeoutSeconds = prefs.getInt("search_timeout_seconds", 15).coerceIn(5, 60)
        searchIntervalMs = prefs.getInt("search_interval_ms", 120).let { if (it == 350) 120 else it }.coerceIn(100, 2000)
        grayscaleCapture = prefs.getBoolean("grayscale_capture", false)
        if (steps.none { it.id == selectedStepId }) selectedStepId = steps.firstOrNull { !it.isDelay }?.id ?: -1L
        lastTapAt = 0L
    }

    fun updateScript(name: String, description: String) = synchronized(lock) {
        scriptName = name.ifBlank { "اسکریپت من" }
        scriptDescription = description
        persist()
    }

    fun updateRepeatCount(count: Int) = synchronized(lock) {
        repeatCount = count.coerceIn(0, 999_999)
        persist()
    }

    fun updatePatchSize(width: Int, height: Int) = synchronized(lock) {
        patchWidth = width.coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        patchHeight = height.coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        persistSettings()
    }

    fun updateMatchSettings(threshold: Float = matchThreshold, timeoutSeconds: Int = searchTimeoutSeconds) = synchronized(lock) {
        matchThreshold = threshold.coerceIn(50f, 95f)
        searchTimeoutSeconds = timeoutSeconds.coerceIn(5, 60)
        persistSettings()
    }

    fun updateSearchInterval(intervalMs: Int) = synchronized(lock) {
        searchIntervalMs = intervalMs.coerceIn(100, 2000)
        persistSettings()
    }

    fun updateGrayscaleCapture(enabled: Boolean) = synchronized(lock) {
        grayscaleCapture = enabled
        persistSettings()
    }

    fun save() = synchronized(lock) { persist() }

    fun selectStart(id: Long) = synchronized(lock) {
        selectedStepId = id
        appContext.getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putLong("selected", id).apply()
    }

    fun selectedIndex(): Int = steps.indexOfFirst { it.id == selectedStepId }.takeIf { it >= 0 }
        ?: steps.indexOfFirst { !it.isDelay }

    fun beginRecording() = synchronized(lock) { lastTapAt = 0L }

    fun recordTap(frame: Bitmap, x: Float, y: Float, timeMs: Long = SystemClock.elapsedRealtime()) = synchronized(lock) {
        val delay = if (lastTapAt == 0L) 0L else (timeMs - lastTapAt).coerceAtLeast(0L)
        lastTapAt = timeMs
        addImageLocked(frame, x, y, delay, saveCapturePreview = true)
        status = "لمس ضبط شد · فاصله ${delay}ms"
    }

    fun addTarget(frame: Bitmap, x: Float, y: Float) = synchronized(lock) {
        addImageLocked(frame, x, y, 0L)
        status = "هدف تصویری اضافه شد"
    }

    private fun addImageLocked(frame: Bitmap, x: Float, y: Float, delay: Long, saveCapturePreview: Boolean = false) {
        val id = System.nanoTime()
        val name = "$id.jpg"
        val captureName = if (saveCapturePreview) "$id-capture.jpg" else null
        val captureCopy = if (saveCapturePreview) frame.copy(Bitmap.Config.ARGB_8888, true) else null
        val patch = centeredPatch(frame, x, y, patchWidth, patchHeight)
        if (grayscaleCapture) makeGrayscale(patch)
        saveBitmap(patch, File(appContext.filesDir, name))
        steps.add(MacroStep(id, name, delay, patchWidth / 2f, patchHeight / 2f, captureName, x, y, grayscaleCapture))
        persist()
        if (captureCopy != null && captureName != null) {
            Thread({ saveCapturePreview(captureCopy, x, y, File(appContext.filesDir, captureName)) }, "macro-capture-preview").start()
        }
    }

    fun copyAction(index: Int): Boolean = synchronized(lock) {
        val step = steps.getOrNull(index) ?: return@synchronized false
        val clipboardFile = File(appContext.cacheDir, "macro-action-clipboard.jpg")
        if (step.imageName != null) {
            val bitmap = image(step) ?: return@synchronized false
            saveBitmap(bitmap, clipboardFile)
            copiedImageFile = clipboardFile
        } else copiedImageFile = null
        copiedAction = step
        true
    }

    fun hasCopiedAction(): Boolean = copiedAction != null

    fun pasteAction(after: Int = steps.lastIndex): Boolean = synchronized(lock) {
        val copied = copiedAction ?: return@synchronized false
        val id = System.nanoTime()
        val imageName = if (copied.imageName != null) {
            val source = copiedImageFile?.takeIf(File::exists) ?: return@synchronized false
            val bitmap = BitmapFactoryCompat.decode(source) ?: return@synchronized false
            val name = "$id-copy.jpg"
            saveBitmap(bitmap, File(appContext.filesDir, name))
            name
        } else null
        val step = copied.copy(id = id, imageName = imageName, capturePreviewName = null)
        val index = (after + 1).coerceIn(0, steps.size)
        steps.add(index, step)
        persist()
        status = "اکشن چسبانده شد"
        true
    }

    fun addDelay(after: Int, duration: Long = 500L) = synchronized(lock) {
        val step = MacroStep(System.nanoTime(), null, duration)
        steps.add((after + 1).coerceIn(0, steps.size), step)
        persist()
    }

    fun updateDelay(index: Int, duration: Long) = synchronized(lock) {
        if (index in steps.indices) {
            steps[index] = steps[index].copy(delayMs = duration.coerceIn(0L, 600_000L))
            persist()
        }
    }

    fun moveStep(index: Int, delta: Int) = synchronized(lock) {
        val target = index + delta
        if (index !in steps.indices || target !in steps.indices) return@synchronized
        val step = steps.removeAt(index)
        steps.add(target, step)
        persist()
    }

    fun delete(index: Int) = synchronized(lock) {
        if (index in steps.indices) {
            val removed = steps.removeAt(index)
            removed.imageName?.let { File(appContext.filesDir, it).delete() }
            removed.capturePreviewName?.let { File(appContext.filesDir, it).delete() }
            if (removed.id == selectedStepId) selectedStepId = steps.firstOrNull { !it.isDelay }?.id ?: -1L
            persist()
        }
    }

    fun deleteAll() = synchronized(lock) {
        steps.forEach {
            it.imageName?.let { name -> File(appContext.filesDir, name).delete() }
            it.capturePreviewName?.let { name -> File(appContext.filesDir, name).delete() }
        }
        steps.clear()
        selectedStepId = -1L
        persist()
    }

    fun image(step: MacroStep): Bitmap? = step.imageName?.let { BitmapFactoryCompat.decode(File(appContext.filesDir, it)) }

    fun capturePreview(step: MacroStep): Bitmap? = step.capturePreviewName?.let { BitmapFactoryCompat.decode(File(appContext.filesDir, it)) }

    fun replace(id: Long, frame: Bitmap, centerX: Float, centerY: Float, boxWidth: Float, boxHeight: Float, pointX: Float, pointY: Float) = synchronized(lock) {
        val index = steps.indexOfFirst { it.id == id }
        if (index < 0) return@synchronized
        val old = steps[index]
        val width = boxWidth.roundToInt().coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        val height = boxHeight.roundToInt().coerceIn(MIN_PATCH_SIZE, MAX_PATCH_SIZE)
        val left = centerX - width / 2f
        val top = centerY - height / 2f
        val patch = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val matrix = Matrix().apply { postTranslate(-left, -top) }
        Canvas(patch).apply { drawColor(android.graphics.Color.BLACK); drawBitmap(frame, matrix, Paint(Paint.FILTER_BITMAP_FLAG)) }
        if (grayscaleCapture) makeGrayscale(patch)
        val name = "${old.id}-${System.nanoTime()}-edited.jpg"
        saveBitmap(patch, File(appContext.filesDir, name))
        old.imageName?.takeIf { it != name }?.let { File(appContext.filesDir, it).delete() }
        old.capturePreviewName?.let { File(appContext.filesDir, it).delete() }
        steps[index] = old.copy(imageName = name, tapX = (pointX - left).coerceIn(0f, width.toFloat()), tapY = (pointY - top).coerceIn(0f, height.toFloat()), capturePreviewName = null, grayscale = grayscaleCapture)
        persist()
    }

    private fun centeredPatch(bitmap: Bitmap, x: Float, y: Float, width: Int, height: Int): Bitmap {
        val patch = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val matrix = Matrix().apply { postTranslate(width / 2f - x, height / 2f - y) }
        Canvas(patch).apply { drawColor(android.graphics.Color.BLACK); drawBitmap(bitmap, matrix, paint) }
        return patch
    }

    private fun makeGrayscale(bitmap: Bitmap) {
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val value = (android.graphics.Color.red(pixel) * 30 + android.graphics.Color.green(pixel) * 59 + android.graphics.Color.blue(pixel) * 11) / 100
            pixels[i] = android.graphics.Color.rgb(value, value, value)
        }
        bitmap.setPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
    }

    private fun saveBitmap(bitmap: Bitmap, file: File, format: Bitmap.CompressFormat = Bitmap.CompressFormat.JPEG) {
        try {
            file.parentFile?.mkdirs()
            FileOutputStream(file).use {
                check(bitmap.compress(format, if (format == Bitmap.CompressFormat.JPEG) 92 else 100, it)) {
                    "Could not encode bitmap: ${file.name}"
                }
            }
        } finally {
            // Callers transfer ownership of the bitmap to this method.
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun saveCapturePreview(source: Bitmap, x: Float, y: Float, file: File) {
        val scale = (1200f / maxOf(source.width, source.height)).coerceAtMost(1f)
        val preview = if (scale < 1f) Bitmap.createScaledBitmap(source, (source.width * scale).roundToInt(), (source.height * scale).roundToInt(), true) else source
        try {
            val markerX = x * preview.width / source.width
            val markerY = y * preview.height / source.height
            val radius = (preview.width / 42f).coerceAtLeast(10f)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.RED
                style = Paint.Style.STROKE
                strokeWidth = (preview.width / 180f).coerceAtLeast(3f)
            }
            Canvas(preview).apply {
                drawCircle(markerX, markerY, radius, paint)
                drawLine(markerX - radius * 1.5f, markerY, markerX + radius * 1.5f, markerY, paint)
                drawLine(markerX, markerY - radius * 1.5f, markerX, markerY + radius * 1.5f, paint)
            }
            FileOutputStream(file).use { preview.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        } finally {
            preview.recycle()
            if (source !== preview) source.recycle()
        }
    }

    private fun persist() {
        val array = JSONArray()
        steps.forEach { step ->
            array.put(JSONObject().put("id", step.id).put("image", step.imageName ?: "").put("delay", step.delayMs).put("x", step.tapX.toDouble()).put("y", step.tapY.toDouble()).put("capture", step.capturePreviewName ?: "").put("cx", step.captureX?.toDouble()).put("cy", step.captureY?.toDouble()).put("gray", step.grayscale))
        }
        appContext.getSharedPreferences("macro", Context.MODE_PRIVATE).edit()
            .putString("steps", array.toString())
            .putLong("selected", selectedStepId)
            .putString("name", scriptName)
            .putString("description", scriptDescription)
            .putInt("repeat_count", repeatCount)
            .remove("loop")
            .putInt("patch_width", patchWidth)
            .putInt("patch_height", patchHeight)
            .putFloat("match_threshold", matchThreshold)
            .putInt("search_timeout_seconds", searchTimeoutSeconds)
            .putInt("search_interval_ms", searchIntervalMs)
            .putBoolean("grayscale_capture", grayscaleCapture)
            .apply()
    }

    private fun persistSettings() {
        appContext.getSharedPreferences("macro", Context.MODE_PRIVATE).edit()
            .putInt("patch_width", patchWidth)
            .putInt("patch_height", patchHeight)
            .putFloat("match_threshold", matchThreshold)
            .putInt("search_timeout_seconds", searchTimeoutSeconds)
            .putInt("search_interval_ms", searchIntervalMs)
            .putBoolean("grayscale_capture", grayscaleCapture)
            .apply()
    }
}

private object BitmapFactoryCompat {
    fun decode(file: File): Bitmap? = if (file.exists()) android.graphics.BitmapFactory.decodeFile(file.absolutePath) else null
}

data class Match(val x: Int, val y: Int, val score: Float, val scaleX: Float, val scaleY: Float)

object ImageMatcher {
    private class Samples(val idx: IntArray, val dx: IntArray, val dy: IntArray, val centered: FloatArray, val energy: Float, val mean: Float)
    private data class CoarseHit(val x: Int, val y: Int, val score: Float)

    fun find(screen: Bitmap, template: Bitmap, region: Rect? = null, grayscaleTemplate: Boolean = false): Match? {
        if (screen.width < 24 || screen.height < 24 || template.width < 8 || template.height < 8) return null
        val bounds = region?.let { Rect(it.left.coerceAtLeast(0), it.top.coerceAtLeast(0), it.right.coerceAtMost(screen.width), it.bottom.coerceAtMost(screen.height)) }
        if (region != null && (bounds == null || bounds.isEmpty)) return null
        val smallestSide = minOf(template.width, template.height)
        // قالب در فضای درشت‌شده حدود ۲۰ پیکسل می‌شود: نه خیلی کوچک (از دست رفتن جزئیات) و نه خیلی بزرگ (کند)
        val divisor = (smallestSide / 20).coerceIn(2, 5)
        val sw = (screen.width / divisor).coerceAtLeast(1)
        val sh = (screen.height / divisor).coerceAtLeast(1)
        val screenScaleX = screen.width.toFloat() / sw
        val screenScaleY = screen.height.toFloat() / sh
        val smallScreen = scaledBitmap(screen, sw, sh, filter = true)
        try {
            val pixels = IntArray(sw * sh).also { smallScreen.getPixels(it, 0, sw, 0, 0, sw, sh) }
            val grayScreen = IntArray(pixels.size) { gray(pixels[it]) }
            var bestMatch: Match? = null
            val fullWidth = template.width.coerceAtLeast(8)
            val fullHeight = template.height.coerceAtLeast(8)
            if (fullWidth > screen.width || fullHeight > screen.height) return null
            val tw = (fullWidth.toFloat() * sw / screen.width).roundToInt().coerceAtLeast(8)
            val th = (fullHeight.toFloat() * sh / screen.height).roundToInt().coerceAtLeast(8)
            if (tw > sw || th > sh) return null
                val smallTemplate = scaledBitmap(template, tw, th, filter = true)
                try {
                    val templatePixels = IntArray(tw * th).also { smallTemplate.getPixels(it, 0, tw, 0, 0, tw, th) }
                    val target = IntArray(templatePixels.size) { gray(templatePixels[it]) }
                    val coarseStride = kotlin.math.ceil(kotlin.math.sqrt(tw * th / 64.0)).toInt().coerceAtLeast(1)
                    val coarseSamples = makeSamples(target, tw, th, coarseStride)
                    val maxX = sw - tw
                    val maxY = sh - th
                    val minSearchX = bounds?.let { kotlin.math.floor(it.left / screenScaleX).toInt().coerceAtLeast(0) } ?: 0
                    val minSearchY = bounds?.let { kotlin.math.floor(it.top / screenScaleY).toInt().coerceAtLeast(0) } ?: 0
                    val maxSearchX = bounds?.let { kotlin.math.ceil((it.right - fullWidth) / screenScaleX).toInt().coerceAtMost(maxX) } ?: maxX
                    val maxSearchY = bounds?.let { kotlin.math.ceil((it.bottom - fullHeight) / screenScaleY).toInt().coerceAtMost(maxY) } ?: maxY
                    if (minSearchX > maxSearchX || minSearchY > maxSearchY) return null
                    val searchStride = 3
                    val coarseHits = ArrayList<CoarseHit>(4)
                    val separationX = (tw / 2).coerceAtLeast(searchStride)
                    val separationY = (th / 2).coerceAtLeast(searchStride)
                    val searchXs = scanPositions(minSearchX, maxSearchX, searchStride)
                    val searchYs = scanPositions(minSearchY, maxSearchY, searchStride)
                    for (y in searchYs) for (x in searchXs) {
                        val score = scoreAt(pixels, grayScreen, sw, x, y, templatePixels, coarseSamples, useColor = false)
                        if (coarseHits.size >= 3 && score <= coarseHits.minOf { it.score }) continue
                        val nearby = coarseHits.indexOfFirst {
                            abs(it.x - x) < separationX && abs(it.y - y) < separationY
                        }
                        if (nearby >= 0) {
                            if (score > coarseHits[nearby].score) coarseHits[nearby] = CoarseHit(x, y, score)
                        } else if (coarseHits.size < 3) {
                            coarseHits.add(CoarseHit(x, y, score))
                        } else {
                            val weakest = coarseHits.indices.minByOrNull { coarseHits[it].score } ?: continue
                            if (score > coarseHits[weakest].score) coarseHits[weakest] = CoarseHit(x, y, score)
                        }
                    }
                    smallTemplate.recycle()

                    val fullTemplate = scaledBitmap(template, fullWidth, fullHeight, filter = false)
                    try {
                        val fullPixels = IntArray(fullWidth * fullHeight).also { fullTemplate.getPixels(it, 0, fullWidth, 0, 0, fullWidth, fullHeight) }
                        val fullGray = IntArray(fullPixels.size) { gray(fullPixels[it]) }
                    val sampleStride = kotlin.math.ceil(kotlin.math.sqrt(fullWidth * fullHeight / 400.0)).toInt().coerceAtLeast(1)
                        val refineSamples = makeSamples(fullGray, fullWidth, fullHeight, sampleStride)
                        val radiusX = (searchStride * screenScaleX).roundToInt() + 1
                        val radiusY = (searchStride * screenScaleY).roundToInt() + 1
                        for (hit in coarseHits) {
                            val expectedX = (hit.x * screenScaleX).roundToInt()
                            val expectedY = (hit.y * screenScaleY).roundToInt()
                            val left = (expectedX - radiusX).coerceAtLeast(bounds?.left ?: 0)
                            val top = (expectedY - radiusY).coerceAtLeast(bounds?.top ?: 0)
                            val right = (expectedX + radiusX).coerceAtMost(minOf(screen.width - fullWidth, bounds?.right?.minus(fullWidth) ?: screen.width - fullWidth))
                            val bottom = (expectedY + radiusY).coerceAtMost(minOf(screen.height - fullHeight, bounds?.bottom?.minus(fullHeight) ?: screen.height - fullHeight))
                            if (left > right || top > bottom) continue
                            val cropWidth = right - left + fullWidth
                            val cropHeight = bottom - top + fullHeight
                            val cropPixels = IntArray(cropWidth * cropHeight)
                            screen.getPixels(cropPixels, 0, cropWidth, left, top, cropWidth, cropHeight)
                            val cropGray = IntArray(cropPixels.size) { gray(cropPixels[it]) }
                            var refinedX = expectedX
                            var refinedY = expectedY
                            var refinedScore = -1f
                            for (y in top..bottom) for (x in left..right) {
                                val score = scoreAt(cropPixels, cropGray, cropWidth, x - left, y - top, fullPixels, refineSamples, useColor = !grayscaleTemplate)
                                if (score > refinedScore) {
                                    refinedScore = score
                                    refinedX = x
                                    refinedY = y
                                }
                            }
                            val candidate = Match(refinedX, refinedY, refinedScore, fullWidth.toFloat() / template.width, fullHeight.toFloat() / template.height)
                            if (bestMatch == null || candidate.score > bestMatch.score) bestMatch = candidate
                        }
                    } finally {
                        fullTemplate.recycle()
                    }
                } finally {
                    if (!smallTemplate.isRecycled) smallTemplate.recycle()
                }
            return bestMatch
        } finally {
            smallScreen.recycle()
        }
    }

    private fun scanPositions(min: Int, max: Int, stride: Int): IntArray {
        if (min > max) return intArrayOf()
        val positions = (min..max step stride).toMutableList()
        if (positions.last() != max) positions.add(max)
        return positions.toIntArray()
    }

    private fun scaledBitmap(bitmap: Bitmap, width: Int, height: Int, filter: Boolean): Bitmap =
        if (bitmap.width == width && bitmap.height == height) bitmap.copy(Bitmap.Config.ARGB_8888, false)
        else Bitmap.createScaledBitmap(bitmap, width, height, filter)

    private fun gray(pixel: Int) = (android.graphics.Color.red(pixel) * 30 + android.graphics.Color.green(pixel) * 59 + android.graphics.Color.blue(pixel) * 11) / 100

    private fun makeSamples(target: IntArray, width: Int, height: Int, stride: Int): Samples {
        val count = ((height + stride - 1) / stride) * ((width + stride - 1) / stride)
        val idx = IntArray(count)
        val dx = IntArray(count)
        val dy = IntArray(count)
        var n = 0
        for (y in 0 until height step stride) for (x in 0 until width step stride) {
            idx[n] = y * width + x; dx[n] = x; dy[n] = y; n++
        }
        var mean = 0f
        for (i in 0 until n) mean += target[idx[i]]
        mean /= n.coerceAtLeast(1)
        val centered = FloatArray(n) { target[idx[it]] - mean }
        var energy = 0f
        for (v in centered) energy += v * v
        return Samples(idx.copyOf(n), dx.copyOf(n), dy.copyOf(n), centered, energy, mean)
    }

    private fun scoreAt(screenPixels: IntArray, screenGray: IntArray, width: Int, x: Int, y: Int, templatePixels: IntArray, samples: Samples, useColor: Boolean): Float {
        val n = samples.idx.size
        var sum = 0f
        for (i in 0 until n) sum += screenGray[(y + samples.dy[i]) * width + x + samples.dx[i]]
        val mean = sum / n.coerceAtLeast(1)
        var covariance = 0f
        var energy = 0f
        var colorError = 0.0
        var colorCount = 0
        for (i in 0 until n) {
            val screenIndex = (y + samples.dy[i]) * width + x + samples.dx[i]
            val value = screenGray[screenIndex] - mean
            covariance += value * samples.centered[i]
            energy += value * value
            if (useColor) {
                val pixel = screenPixels[screenIndex]
                val targetPixel = templatePixels[samples.idx[i]]
                val targetTotal = android.graphics.Color.red(targetPixel) + android.graphics.Color.green(targetPixel) + android.graphics.Color.blue(targetPixel)
                val screenTotal = android.graphics.Color.red(pixel) + android.graphics.Color.green(pixel) + android.graphics.Color.blue(pixel)
                if (targetTotal > 24 && screenTotal > 24) {
                    val dr = android.graphics.Color.red(targetPixel).toFloat() / targetTotal - android.graphics.Color.red(pixel).toFloat() / screenTotal
                    val dg = android.graphics.Color.green(targetPixel).toFloat() / targetTotal - android.graphics.Color.green(pixel).toFloat() / screenTotal
                    colorError += dr * dr + dg * dg
                    colorCount++
                }
            }
        }
        val grayScore = if (energy < 1f || samples.energy < 1f) {
            (100f - abs(mean - samples.mean) * (100f / 255f)).coerceIn(0f, 100f)
        } else {
            ((covariance / kotlin.math.sqrt(energy * samples.energy)).coerceIn(0f, 1f) * 100f)
        }
        if (!useColor || colorCount == 0) return grayScore
        val colorScore = (1.0 - 3.0 * kotlin.math.sqrt(colorError / (colorCount * 2.0))).coerceIn(0.0, 1.0).toFloat() * 100f
        return grayScore * 0.6f + colorScore * 0.4f
    }
}

object MacroRunner {
    private val active = AtomicBoolean(false)
    private val confirmedMatches = HashMap<Long, Match>()
    @Volatile private var worker: Thread? = null
    @Volatile private var activeSince = 0L
    @Volatile private var elapsedBeforePause = 0L
    var isRunning by mutableStateOf(false)
        private set
    var isPaused by mutableStateOf(false)
        private set
    var currentStepIndex by mutableIntStateOf(-1)
        private set

    fun elapsedMillis(): Long = if (!isRunning) 0L else elapsedBeforePause + if (isPaused) 0L else (SystemClock.elapsedRealtime() - activeSince).coerceAtLeast(0L)

    fun stop() {
        active.set(false)
        isPaused = false
        worker?.interrupt()
        MacroStore.status = "اجرای ماکرو متوقف شد"
        refreshFloating()
    }

    fun pause() {
        if (!active.get() || isPaused) return
        elapsedBeforePause += (SystemClock.elapsedRealtime() - activeSince).coerceAtLeast(0L)
        isPaused = true
        MacroStore.status = "اجرای ماکرو مکث شد"
        refreshFloating()
    }

    fun start(from: Int, threshold: Float = MacroStore.matchThreshold, repeatCount: Int = MacroStore.repeatCount, searchTimeoutMs: Long = MacroStore.searchTimeoutSeconds * 1000L) {
        if (active.get()) {
            if (isPaused) {
                activeSince = SystemClock.elapsedRealtime()
                isPaused = false
                MacroStore.status = "اجرای ماکرو ادامه یافت"
                refreshFloating()
            }
            return
        }
        if (from !in MacroStore.steps.indices) { MacroStore.status = "ابتدا یک تصویر برای شروع انتخاب کنید"; return }
        if (!ScreenCaptureService.hasFrame()) { MacroStore.status = "اشتراک‌گذاری صفحه فعال نیست یا هنوز فریمی نرسیده"; return }
        if (!active.compareAndSet(false, true)) return
        elapsedBeforePause = 0L
        confirmedMatches.clear()
        activeSince = SystemClock.elapsedRealtime()
        isRunning = true
        isPaused = false
        refreshFloating()
        worker = Thread {
            try {
                val service = MacroAccessibilityService.instance
                if (service == null) { MacroStore.status = "ابتدا Accessibility را در تنظیمات فعال کنید"; return@Thread }
                var failed = false
                var completedRuns = 0
                do {
                    for (index in from.coerceAtLeast(0) until MacroStore.steps.size) {
                        waitUntilResumed()
                        if (!active.get()) break
                        currentStepIndex = index
                        val step = MacroStore.steps.getOrNull(index) ?: continue
                        if (step.isDelay) {
                            sleepActive(step.delayMs)
                            continue
                        }
                        if (index > from) sleepActive(step.delayMs)
                        val template = MacroStore.image(step) ?: continue
                        MacroStore.lastMatch = null
                        val searchStartedAt = SystemClock.elapsedRealtime()
                        var match: Match? = null
                        var sawLiveFrame = false
                        var hadUnstableCandidate = false
                        var stableCandidate: Match? = null
                        var stableFrameCount = 0
                         var lastFrameSequence = ScreenCaptureService.requestFreshFrame()
                        while (active.get() && SystemClock.elapsedRealtime() - searchStartedAt < searchTimeoutMs) {
                            waitUntilResumed()
                            if (!active.get()) break
                            if (ScreenCaptureService.frameSequence() != lastFrameSequence) {
                                val captured = ScreenCaptureService.latestFrameSnapshot()
                                if (captured != null) {
                                    lastFrameSequence = captured.sequence
                                    sawLiveFrame = true
                                    val candidate = try {
                                        val localRegion = confirmedMatches[step.id]?.let { regionAround(it, template) }
                                        val localMatch = localRegion?.let { region ->
                                            runCatching { ImageMatcher.find(captured.bitmap, template, region, step.grayscale) }.getOrNull()
                                        }
                                        val fullMatch = if (localMatch == null || localMatch.score < threshold) {
                                            runCatching { ImageMatcher.find(captured.bitmap, template, grayscaleTemplate = step.grayscale) }.getOrNull()
                                        } else null
                                        listOfNotNull(localMatch, fullMatch).maxByOrNull { it.score }
                                    } finally {
                                        captured.bitmap.recycle()
                                    }
                                    MacroStore.lastMatch = candidate?.score
                                    if (candidate != null && candidate.score >= threshold) {
                                        hadUnstableCandidate = true
                                        val previous = stableCandidate
                                        val tolerance = maxOf(5f, minOf(template.width * candidate.scaleX, template.height * candidate.scaleY) * 0.35f)
                                        stableFrameCount = if (previous != null && abs(previous.x - candidate.x) <= tolerance && abs(previous.y - candidate.y) <= tolerance) {
                                            stableFrameCount + 1
                                        } else 1
                                        stableCandidate = candidate
                                        if (stableFrameCount >= 2 || candidate.score >= 92f) {
                                            match = candidate
                                            confirmedMatches[step.id] = candidate
                                            break
                                        }
                                    } else {
                                        stableCandidate = null
                                        stableFrameCount = 0
                                    }
                                }
                            }
                            val elapsed = SystemClock.elapsedRealtime() - searchStartedAt
                            val remaining = (searchTimeoutMs - elapsed).coerceAtLeast(0L)
                            if (remaining > 0L) sleepActive(minOf(MacroStore.searchIntervalMs.toLong(), remaining))
                        }
                        template.recycle()
                        if (!active.get()) break
                        if (match == null || match.score < threshold) {
                            val best = MacroStore.lastMatch?.roundToInt()
                            MacroStore.status = when {
                                hadUnstableCandidate -> "هدف ${index + 1} پایدار نبود؛ تطبیق باید در دو فریم تازه تأیید شود"
                                best != null -> "هدف ${index + 1} پیدا نشد؛ بهترین شباهت ${best}٪ از ${threshold.roundToInt()}٪"
                                sawLiveFrame -> "تصویر هدف قابل تطبیق نیست؛ نمونهٔ واضح‌تری ثبت کنید"
                                else -> "فریم زنده دریافت نشد؛ اشتراک‌گذاری صفحه را بررسی کنید"
                            }
                            failed = true
                            break
                        }
                        val x = match.x + step.tapX * match.scaleX
                        val y = match.y + step.tapY * match.scaleY
                        MacroStore.status = "تطبیق ${match.score.roundToInt()}٪ · اجرای لمس ${index + 1}"
                        refreshFloating()
                        val gestureFinished = CountDownLatch(1)
                        service.tap(x, y) { gestureFinished.countDown() }
                        gestureFinished.await(2L, TimeUnit.SECONDS)
                    }
                    completedRuns++
                } while (active.get() && (repeatCount == 0 || completedRuns < repeatCount) && !failed)
                if (active.get() && !failed) MacroStore.status = if (repeatCount == 0) "حلقهٔ ماکرو ادامه دارد" else "اجرای ماکرو تمام شد"
            } catch (_: InterruptedException) {
                if (active.get()) MacroStore.status = "اجرای ماکرو مکث شد"
            } finally {
                active.set(false)
                isRunning = false
                isPaused = false
                currentStepIndex = -1
                worker = null
                refreshFloating()
            }
        }.also(Thread::start)
    }

    private fun regionAround(match: Match, template: Bitmap): Rect {
        val width = (template.width * match.scaleX).roundToInt().coerceAtLeast(8)
        val height = (template.height * match.scaleY).roundToInt().coerceAtLeast(8)
        val padding = (minOf(width, height) / 2).coerceAtLeast(16)
        return Rect(match.x - padding, match.y - padding, match.x + width + padding, match.y + height + padding)
    }

    private fun waitUntilResumed(): Long {
        var waited = 0L
        while (active.get() && isPaused) {
            val before = SystemClock.elapsedRealtime()
            Thread.sleep(100L)
            waited += (SystemClock.elapsedRealtime() - before).coerceAtLeast(0L)
        }
        return waited
    }

    private fun sleepActive(durationMs: Long) {
        var remaining = durationMs.coerceAtLeast(0L)
        while (active.get() && remaining > 0L) {
            waitUntilResumed()
            if (!active.get()) return
            val slice = remaining.coerceAtMost(100L)
            val before = SystemClock.elapsedRealtime()
            Thread.sleep(slice)
            remaining -= (SystemClock.elapsedRealtime() - before).coerceAtLeast(1L)
        }
    }

    private fun refreshFloating() {
        Handler(Looper.getMainLooper()).post { MacroAccessibilityService.instance?.refreshFloatingMenu() }
    }
}
