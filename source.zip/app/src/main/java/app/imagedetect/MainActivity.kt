package app.imagedetect

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.media.projection.MediaProjectionConfig
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.material3.Text as MaterialText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val Ink = Color(0xFF101010)
private val PanelColor = Color(0xFF202020)
private val Mint = Color(0xFF7C5CFF)
private val Blue = Color(0xFF4FD0FF)
private val Muted = Color(0xFFAAAAAA)

@Composable
private fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    maxLines: Int = Int.MAX_VALUE
) = MaterialText(
    text = AppLanguage.translate(text), modifier = modifier, color = color, fontSize = fontSize,
    fontWeight = fontWeight, textAlign = textAlign, lineHeight = lineHeight,
    letterSpacing = letterSpacing, maxLines = maxLines
)

@Composable
private fun LanguageChoices() {
    val context = LocalContext.current
    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("fa" to "فارسی", "en" to "English", "ru" to "Русский").forEach { (code, label) ->
            TextButton(onClick = { AppLanguage.select(context, code) }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                Text(label, color = if (AppLanguage.current == code) Blue else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_EDITOR = "open_script_editor"
    }

    private val shareScreen = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            ContextCompat.startForegroundService(this, service)
        } else MacroStore.status = "مجوز اشتراک‌گذاری صفحه رد شد"
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MacroStore.initialize(this)
        AppLanguage.initialize(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Ink, surface = PanelColor)) {
                CompositionLocalProvider(LocalLayoutDirection provides if (AppLanguage.current == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    StudioScreen(
                        openEditor = intent.getBooleanExtra(EXTRA_OPEN_EDITOR, false),
                        onShare = {
                            val manager = getSystemService(MediaProjectionManager::class.java)
                            val intent = if (android.os.Build.VERSION.SDK_INT >= 34) {
                                manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice())
                            } else manager.createScreenCaptureIntent()
                            shareScreen.launch(intent)
                        },
                        onAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        onRestrictedSettings = {
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.fromParts("package", packageName, null)))
                        },
                        onRecord = { enabled ->
                            if (!enabled) {
                                MacroAccessibilityService.instance?.setRecording(false)
                                true
                            } else MacroAccessibilityService.instance?.setRecording(true) ?: run {
                                MacroStore.status = "ابتدا Accessibility را در تنظیمات فعال کنید"
                                false
                            }
                        },
                        onPlay = { index, threshold, timeoutSeconds ->
                            MacroRunner.start(index, threshold, MacroStore.repeatCount, timeoutSeconds * 1000L)
                            Handler(Looper.getMainLooper()).postDelayed({ moveTaskToBack(true) }, 700L)
                        },
                        onPause = { MacroRunner.pause() },
                        onStopMacro = { MacroRunner.stop() },
                        onLeaveForRecording = { Handler(Looper.getMainLooper()).postDelayed({ moveTaskToBack(true) }, 500L) },
                        onAddTarget = {
                            val frame = ScreenCaptureService.latestFrame()
                            if (frame == null) MacroStore.status = "برای افزودن هدف، اشتراک‌گذاری صفحه را فعال کنید"
                            else {
                                MacroStore.addTarget(frame, frame.width / 2f, frame.height / 2f)
                                frame.recycle()
                            }
                        },
                        onAddDelay = { duration -> MacroStore.addDelay(MacroStore.selectedIndex(), duration) },
                        onCopyAction = { index -> MacroStore.copyAction(index) },
                        onPasteAction = { after -> MacroStore.pasteAction(after) },
                        onSaveScript = { name, description -> MacroStore.updateScript(name, description) },
                        onRepeatCountChanged = { count -> MacroStore.updateRepeatCount(count) },
                        onReplace = { step ->
                            val service = MacroAccessibilityService.instance
                            if (service != null && ScreenCaptureService.hasFrame()) {
                                MacroStore.status = "کادر جای‌گذاری زنده روی بازی باز شد"
                                service.requestReplacement(step.id)
                                Handler(Looper.getMainLooper()).postDelayed({ moveTaskToBack(true) }, 250L)
                            } else {
                                MacroStore.status = if (service == null) "برای جایگذاری زنده، Accessibility را فعال کنید" else "برای ویرایش، اشتراک‌گذاری صفحه را فعال کنید"
                            }
                        },
                        onTest = { step, click, matchThreshold -> testMatch(step, click, matchThreshold) }
                    )
                }
            }
        }
    }

    private fun testMatch(step: MacroStep, click: Boolean, threshold: Float) {
        val template = MacroStore.image(step)
        if (template == null) {
            MacroStore.status = "اسکرین‌شات آماده نیست؛ مجوز صفحه را بررسی کنید"
            return
        }
        Thread {
            val frame = ScreenCaptureService.freshFrameSnapshot()?.bitmap
            if (frame == null) {
                template.recycle()
                runOnUiThread { MacroStore.status = "فریم تازه دریافت نشد؛ اشتراک‌گذاری صفحه را بررسی کنید" }
                return@Thread
            }
            val match = runCatching { ImageMatcher.find(frame, template, grayscaleTemplate = step.grayscale) }.getOrNull()
            frame.recycle(); template.recycle()
            runOnUiThread {
                MacroStore.lastMatch = match?.score
                if (match == null) MacroStore.status = "تصویر فعلی برای مقایسه در دسترس نیست"
                else {
                    MacroStore.status = "تطبیق تصویر: ${match.score.toInt()}٪"
                    if (click && match.score >= threshold) {
                        val service = MacroAccessibilityService.instance
                        if (service == null) MacroStore.status = "ابتدا Accessibility را فعال کنید"
                        else {
                            service.tap(match.x + step.tapX * match.scaleX, match.y + step.tapY * match.scaleY)
                            MacroStore.status = "تطبیق ${match.score.toInt()}٪؛ لمس ارسال شد"
                            Handler(Looper.getMainLooper()).postDelayed({ moveTaskToBack(true) }, 500L)
                        }
                    } else if (click) MacroStore.status = "بهترین شباهت ${match.score.toInt()}٪ است؛ حد لازم ${threshold.toInt()}٪"
                }
            }
        }.start()
    }
}

@Composable
private fun StudioScreen(
    openEditor: Boolean,
    onShare: () -> Unit,
    onAccessibility: () -> Unit,
    onRestrictedSettings: () -> Unit,
    onRecord: (Boolean) -> Boolean,
    onPlay: (Int, Float, Int) -> Unit,
    onPause: () -> Unit,
    onStopMacro: () -> Unit,
    onLeaveForRecording: () -> Unit,
    onAddTarget: () -> Unit,
    onAddDelay: (Long) -> Unit,
    onCopyAction: (Int) -> Boolean,
    onPasteAction: (Int) -> Boolean,
    onSaveScript: (String, String) -> Unit,
    onRepeatCountChanged: (Int) -> Unit,
    onReplace: (MacroStep) -> Unit,
    onTest: (MacroStep, Boolean, Float) -> Unit
) {
    var editing by remember { mutableStateOf(openEditor) }
    if (editing) {
        ScriptEditor(
            onBack = { editing = false },
            onRecord = onRecord,
            onLeaveForRecording = onLeaveForRecording,
            onAddTarget = onAddTarget,
            onAddDelay = onAddDelay,
            onCopyAction = onCopyAction,
            onPasteAction = onPasteAction,
            onSaveScript = onSaveScript,
            onRepeatCountChanged = onRepeatCountChanged,
            onReplace = onReplace,
            onTest = onTest
        )
    } else {
        MacroHome(
            onSettings = { editing = true },
            onShare = onShare,
            onAccessibility = onAccessibility,
            onRestrictedSettings = onRestrictedSettings,
            onRecord = onRecord,
            onPlay = onPlay,
            onPause = onPause,
            onStopMacro = onStopMacro,
            onLeaveForRecording = onLeaveForRecording
        )
    }
}

@Composable
private fun MacroHome(
    onSettings: () -> Unit,
    onShare: () -> Unit,
    onAccessibility: () -> Unit,
    onRestrictedSettings: () -> Unit,
    onRecord: (Boolean) -> Boolean,
    onPlay: (Int, Float, Int) -> Unit,
    onPause: () -> Unit,
    onStopMacro: () -> Unit,
    onLeaveForRecording: () -> Unit
) {
    val recording = MacroAccessibilityService.recording
    var selectedId by remember { mutableLongStateOf(MacroStore.selectedStepId) }
    var threshold by remember { mutableFloatStateOf(MacroStore.matchThreshold) }
    var timeoutSeconds by remember { mutableIntStateOf(MacroStore.searchTimeoutSeconds) }
    var elapsedTick by remember { mutableLongStateOf(0L) }
    val steps = MacroStore.steps
    val selectedIndex = steps.indexOfFirst { it.id == selectedId }.let { if (it >= 0) it else MacroStore.selectedIndex() }
    val playing = MacroRunner.isRunning
    val paused = MacroRunner.isPaused
    LaunchedEffect(playing, paused) {
        while (playing && !paused) {
            elapsedTick = MacroRunner.elapsedMillis()
            delay(250L)
        }
    }
    val elapsed = if (playing) MacroRunner.elapsedMillis().coerceAtLeast(elapsedTick) else 0L
    val current = MacroRunner.currentStepIndex.takeIf { it >= 0 } ?: selectedIndex
    val stateLabel = when {
        recording -> "در حال ضبط"
        paused -> "مکث شده"
        playing -> "در حال اجرا"
        ScreenCaptureService.hasFrame() -> "آماده"
        else -> "آماده‌سازی لازم است"
    }
    fun moveSelection(delta: Int) {
        val targets = steps.indices.filter { !steps[it].isDelay }
        if (targets.isEmpty()) return
        val currentPosition = targets.indexOf(selectedIndex).let { if (it < 0) 0 else it }
        val nextIndex = targets[(currentPosition + delta).mod(targets.size)]
        selectedId = steps[nextIndex].id
        MacroStore.selectStart(selectedId)
    }
    Box(Modifier.fillMaxSize().background(Ink)) {
        SpaceBackground()
        Box(Modifier.fillMaxSize().safeDrawingPadding()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 18.dp, bottom = 28.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("IMAGE DETECT", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                        Text(MacroStore.scriptName, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(MacroStore.scriptDescription.ifBlank { "کنترل ضبط و اجرای ماکرو" }, color = Muted, fontSize = 12.sp, maxLines = 1)
                        LanguageChoices()
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(onClick = onSettings, modifier = Modifier.size(48.dp).background(PanelColor, CircleShape)) {
                            Text("⚙", color = Color.White, fontSize = 23.sp)
                        }
                        Text("تنظیمات", color = Muted, fontSize = 10.sp)
                    }
                }
            }
            item {
                ScanHero3D(label = stateLabel, status = MacroStore.status, score = MacroStore.lastMatch, active = recording || playing)
            }
            item {
                GlassPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("وضعیت", color = Muted, fontSize = 11.sp)
                            Text(MacroStore.status, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                        Text(stateLabel, color = if (recording || playing) Blue else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button3D("اشتراک صفحه", onShare, Modifier.weight(1f), top = NeoCyan, bottom = NeoBlueDeep, height = 46.dp, fontSize = 12)
                        OutlinedButton(onClick = onRestrictedSettings, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                            Text("Allow restricted settings", fontSize = 9.sp, maxLines = 1)
                        }
                    }
                    OutlinedButton(onClick = onAccessibility, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Text("باز کردن تنظیمات دسترسی‌پذیری", fontSize = 11.sp)
                    }
                    Text("اندروید این مجوز محدود را خودکار فعال نمی‌کند. در اطلاعات برنامه، منوی ⋮ و Allow restricted settings را دستی بزنید؛ سپس Accessibility را فعال کنید. برای ضبط لمس، در اشتراک صفحه «کل صفحه» را انتخاب کنید.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
            item {
                GlassPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("کنترل ماکرو", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("${steps.count { !it.isDelay }} تصویر · ${steps.size} اکشن", color = Muted, fontSize = 12.sp)
                        }
                        Text(formatDuration(elapsed), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { moveSelection(-1) }, enabled = steps.count { !it.isDelay } > 0) { Text("‹  قبلی", color = Color.White) }
                        Text("${if (current >= 0) current + 1 else 0}/${steps.size}", color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        TextButton(onClick = { moveSelection(1) }, enabled = steps.count { !it.isDelay } > 0) { Text("بعدی  ›", color = Color.White) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button3D(
                            if (recording) "■  پایان ضبط" else "●  ضبط اکشن",
                            onClick = {
                                val starting = !recording
                                if (onRecord(starting) && starting) onLeaveForRecording()
                            },
                            modifier = Modifier.weight(1f),
                            top = if (recording) NeoRed else NeoSteel,
                            bottom = if (recording) NeoRedDeep else NeoSteelDeep
                        )
                        Button3D(
                            if (paused) "▶  ادامه" else "▶  شروع ماکرو",
                            onClick = { if (selectedIndex >= 0) onPlay(selectedIndex, threshold, timeoutSeconds) else MacroStore.status = "یک تصویر برای شروع انتخاب کنید" },
                            modifier = Modifier.weight(1f),
                            enabled = selectedIndex >= 0 && (!playing || paused),
                            top = Mint,
                            bottom = NeoIndigo
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = onPause, enabled = playing && !paused, modifier = Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("Ⅱ  مکث", fontSize = 12.sp) }
                        OutlinedButton(onClick = onStopMacro, enabled = playing, modifier = Modifier.weight(1f), shape = RoundedCornerShape(11.dp)) { Text("■  توقف ماکرو", fontSize = 12.sp) }
                    }
                    Text("اجرای ماکرو از اکشن انتخاب‌شده آغاز می‌شود. برای هر تصویر تا $timeoutSeconds ثانیه جست‌وجو می‌شود.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
            item {
                GlassPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("جست‌وجوی تصویر", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("آستانهٔ تطبیق تصویر هنگام اجرا", color = Muted, fontSize = 11.sp)
                        }
                        Text("${threshold.toInt()}٪", color = Blue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Slider(value = threshold, onValueChange = { threshold = it; MacroStore.updateMatchSettings(threshold = it) }, valueRange = 50f..95f, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("فاصلهٔ بررسی تصویر", color = Muted, fontSize = 11.sp)
                        Text("${MacroStore.searchIntervalMs} ms", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(value = MacroStore.searchIntervalMs.toFloat(), onValueChange = {
                        MacroStore.updateSearchInterval(it.toInt())
                    }, valueRange = 100f..2000f, steps = 37, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                    Text("پس از هر بررسی؛ زمان پردازش جداگانه اضافه می‌شود.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("مهلت پیدا کردن هر هدف", color = Muted, fontSize = 11.sp)
                        Text("${timeoutSeconds} ثانیه", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(value = timeoutSeconds.toFloat(), onValueChange = {
                        timeoutSeconds = it.toInt()
                        MacroStore.updateMatchSettings(timeoutSeconds = timeoutSeconds)
                    }, valueRange = 5f..60f, steps = 10, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                    Text("در صورت پیدا نشدن هدف تا پایان مهلت، ماکرو متوقف می‌شود و بهترین شباهت گزارش می‌شود.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        }
    }
}

private fun formatDuration(millis: Long): String {
    val seconds = millis / 1000L
    return String.format(java.util.Locale.US, "%02d:%02d:%02d", seconds / 3600L, seconds / 60L % 60L, seconds % 60L)
}

@Composable
private fun ScriptEditor(
    onBack: () -> Unit,
    onRecord: (Boolean) -> Boolean,
    onLeaveForRecording: () -> Unit,
    onAddTarget: () -> Unit,
    onAddDelay: (Long) -> Unit,
    onCopyAction: (Int) -> Boolean,
    onPasteAction: (Int) -> Boolean,
    onSaveScript: (String, String) -> Unit,
    onRepeatCountChanged: (Int) -> Unit,
    onReplace: (MacroStep) -> Unit,
    onTest: (MacroStep, Boolean, Float) -> Unit
) {
    var name by remember { mutableStateOf(AppLanguage.translate(MacroStore.scriptName)) }
    var description by remember { mutableStateOf(MacroStore.scriptDescription) }
    var repeatCountText by remember { mutableStateOf(MacroStore.repeatCount.toString()) }
    var selectedId by remember { mutableLongStateOf(MacroStore.selectedStepId) }
    var threshold by remember { mutableFloatStateOf(MacroStore.matchThreshold) }
    var timeoutSeconds by remember { mutableIntStateOf(MacroStore.searchTimeoutSeconds) }
    var showAddActions by remember { mutableStateOf(false) }
    var showDelayDialog by remember { mutableStateOf(false) }
    var showOverflow by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var delayText by remember { mutableStateOf("500") }
    val steps = MacroStore.steps
    val selectedIndex = steps.indexOfFirst { it.id == selectedId }.let { if (it >= 0) it else MacroStore.selectedIndex() }
    androidx.compose.ui.window.Dialog(onDismissRequest = onBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f).fillMaxHeight(0.48f).background(Ink, RoundedCornerShape(16.dp)).padding(12.dp)
        ) {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 2.dp, bottom = 12.dp)
            ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    IconButton(onClick = onBack) { Text("‹", color = Color.White, fontSize = 30.sp) }
                    Text("ویرایش اسکریپت", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { showOverflow = true }) { Text("⋮", color = Color.White, fontSize = 25.sp) }
                        DropdownMenu(expanded = showOverflow, onDismissRequest = { showOverflow = false }) {
                            DropdownMenuItem(text = { Text("کپی اکشن انتخاب‌شده") }, onClick = {
                                showOverflow = false
                                if (selectedIndex >= 0 && onCopyAction(selectedIndex)) MacroStore.status = "اکشن کپی شد"
                                else MacroStore.status = "ابتدا یک اکشن را انتخاب کنید"
                            })
                            DropdownMenuItem(text = { Text("حذف همهٔ اکشن‌ها") }, onClick = { showOverflow = false; confirmDelete = true })
                        }
                    }
                    Button(onClick = {
                        onSaveScript(name, description)
                        MacroStore.status = "اسکریپت ذخیره شد"
                        onBack()
                    }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color.White), shape = RoundedCornerShape(8.dp)) { Text("ذخیره") }
                }
            }
            item { LanguageChoices() }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    ScriptField("نام اسکریپت", name, { name = it }, true)
                    ScriptField("توضیح", description, { description = it }, false)
                    Text("مجموع اکشن‌ها: ${steps.size}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(MacroStore.status, color = Muted, fontSize = 11.sp)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { showAddActions = true }, modifier = Modifier.weight(1f).height(48.dp), colors = ButtonDefaults.buttonColors(containerColor = Mint), shape = RoundedCornerShape(8.dp)) { Text("افزودن اکشن", fontWeight = FontWeight.Bold) }
                    OutlinedButton(onClick = {
                        if (!onPasteAction(selectedIndex)) MacroStore.status = "از منوی بالا یک اکشن را کپی کنید"
                    }, enabled = MacroStore.hasCopiedAction(), modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(8.dp)) { Text("چسباندن اکشن") }
                }
            }
            item {
                GlassPanel {
                    Text("تنظیمات هوشمند", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("حداقل شباهت هدف", color = Muted, fontSize = 11.sp)
                        Text("${threshold.toInt()}٪", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(value = threshold, onValueChange = { threshold = it; MacroStore.updateMatchSettings(threshold = it) }, valueRange = 50f..95f, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("فاصلهٔ بررسی تصویر", color = Muted, fontSize = 11.sp)
                        Text("${MacroStore.searchIntervalMs} ms", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(value = MacroStore.searchIntervalMs.toFloat(), onValueChange = {
                        MacroStore.updateSearchInterval(it.toInt())
                    }, valueRange = 100f..2000f, steps = 37, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                    Text("پس از هر بررسی؛ زمان پردازش جداگانه اضافه می‌شود.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("مهلت جست‌وجوی هر تصویر", color = Muted, fontSize = 11.sp)
                        Text("$timeoutSeconds ثانیه", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(value = timeoutSeconds.toFloat(), onValueChange = {
                        timeoutSeconds = it.toInt()
                        MacroStore.updateMatchSettings(timeoutSeconds = timeoutSeconds)
                    }, valueRange = 5f..60f, steps = 10, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
                }
            }
            if (steps.isEmpty()) item {
                Box(Modifier.fillMaxWidth().height(250.dp).background(PanelColor, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(24.dp)) {
                        Text("خالی", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("برای ساخت اکشن، گزینهٔ «افزودن اکشن» را بزنید.", color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp)
                    }
                }
            }
            itemsIndexed(steps, key = { _, step -> step.id }) { index, step ->
                val active = selectedId == step.id || (selectedId == -1L && index == selectedIndex)
                StepCard(
                    step = step,
                    index = index,
                    selected = active,
                    onSelect = { selectedId = step.id; MacroStore.selectStart(step.id) },
                    onReplace = { onReplace(step) },
                    onTest = { onTest(step, false, threshold) },
                    onClickTest = { onTest(step, true, threshold) },
                    onDelete = {
                        MacroStore.delete(index)
                        MacroStore.status = "اکشن حذف شد"
                        if (selectedId == step.id) selectedId = MacroStore.selectedStepId
                    },
                    onDelay = { MacroStore.addDelay(index) },
                    onUpdateDelay = { MacroStore.updateDelay(index, it) },
                    onMove = { MacroStore.moveStep(index, it) },
                    onCopy = { if (onCopyAction(index)) MacroStore.status = "اکشن کپی شد" }
                )
            }
            item {
                var widthText by remember { mutableStateOf(MacroStore.patchWidth.toString()) }
                var heightText by remember { mutableStateOf(MacroStore.patchHeight.toString()) }
                GlassPanel {
                    Text("اندازهٔ کادر تصویر", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("این اندازه برای لمس‌های ضبط‌شدهٔ بعدی استفاده می‌شود.", color = Muted, fontSize = 11.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = widthText, onValueChange = { widthText = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("عرض (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        OutlinedTextField(value = heightText, onValueChange = { heightText = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), label = { Text("ارتفاع (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("کادر فعلی: ${MacroStore.patchWidth} × ${MacroStore.patchHeight}px", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            MacroStore.updatePatchSize(widthText.toIntOrNull() ?: MacroStore.patchWidth, heightText.toIntOrNull() ?: MacroStore.patchHeight)
                            widthText = MacroStore.patchWidth.toString()
                            heightText = MacroStore.patchHeight.toString()
                        }) { Text("اعمال") }
                    }
                    Text("اندازهٔ ۱۶ تا ۵۱۲ پیکسل پذیرفته می‌شود؛ کادر جایگزینی را هم می‌توانید جداگانه تغییر دهید.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
            item {
                GlassPanel {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Column(Modifier.weight(1f)) {
                                Text("تعداد تکرار", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("۰ یعنی بی‌نهایت", color = Muted, fontSize = 11.sp)
                            }
                            OutlinedTextField(
                                value = repeatCountText,
                                onValueChange = { value ->
                                    repeatCountText = value.filter(Char::isDigit).take(6)
                                    onRepeatCountChanged(repeatCountText.toIntOrNull() ?: 0)
                                },
                                modifier = Modifier.width(88.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                    }
                }
            }
        }
    }
    }
    if (showAddActions) AlertDialog(
        onDismissRequest = { showAddActions = false },
        title = { Text("افزودن اکشن") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = {
                    showAddActions = false
                    if (onRecord(true)) onLeaveForRecording()
                }, modifier = Modifier.fillMaxWidth()) { Text("●  ضبط لمس‌ها") }
                TextButton(onClick = { showAddActions = false; onAddTarget() }, modifier = Modifier.fillMaxWidth()) { Text("▣  هدف از تصویر فعلی") }
                TextButton(onClick = { showAddActions = false; showDelayDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("◷  افزودن مکث") }
            }
        },
        confirmButton = { TextButton(onClick = { showAddActions = false }) { Text("بستن") } }
    )
    if (showDelayDialog) AlertDialog(
        onDismissRequest = { showDelayDialog = false },
        title = { Text("افزودن مکث") },
        text = {
            OutlinedTextField(value = delayText, onValueChange = { delayText = it.filter(Char::isDigit).take(6) }, label = { Text("میلی‌ثانیه") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        },
        confirmButton = { TextButton(onClick = { onAddDelay(delayText.toLongOrNull() ?: 500L); showDelayDialog = false }) { Text("افزودن") } },
        dismissButton = { TextButton(onClick = { showDelayDialog = false }) { Text("انصراف") } }
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("حذف همهٔ اکشن‌ها؟") },
        confirmButton = { TextButton(onClick = { MacroStore.deleteAll(); selectedId = -1L; confirmDelete = false }) { Text("حذف همه") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } }
    )
}

@Composable
private fun ScriptField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Muted, fontSize = 11.sp)
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = singleLine,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
            modifier = Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(8.dp)).padding(horizontal = 12.dp, vertical = 11.dp)
        )
    }
}

@Composable
private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .shadow(14.dp, RoundedCornerShape(20.dp), ambientColor = Mint, spotColor = Blue)
            .background(Brush.verticalGradient(listOf(Color(0xE61D2250), Color(0xE60E1330))), RoundedCornerShape(20.dp))
            .border(1.dp, Brush.linearGradient(listOf(Blue.copy(alpha = 0.55f), Mint.copy(alpha = 0.25f))), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content
    )
}

@Composable
private fun StepCard(step: MacroStep, index: Int, selected: Boolean, onSelect: () -> Unit, onReplace: () -> Unit, onTest: () -> Unit, onClickTest: () -> Unit, onDelete: () -> Unit, onDelay: () -> Unit, onUpdateDelay: (Long) -> Unit, onMove: (Int) -> Unit, onCopy: () -> Unit) {
    var delayText by remember(step.id, step.delayMs) { mutableStateOf(step.delayMs.toString()) }
    var confirmDelete by remember(step.id) { mutableStateOf(false) }
    val thumbnail = remember(step.id, step.imageName) { MacroStore.image(step)?.asImageBitmap() }
    Column(
        Modifier.fillMaxWidth()
            .shadow(if (selected) 5.dp else 1.dp, RoundedCornerShape(13.dp))
            .background(if (selected) Color(0xFF1C2C3A) else PanelColor, RoundedCornerShape(13.dp))
            .border(1.dp, if (selected) Blue else Color(0xFF343E49), RoundedCornerShape(13.dp))
            .clickable(onClick = onSelect)
            .padding(horizontal = 11.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(48.dp).background(Color(0xFF101923), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                if (thumbnail != null) Image(thumbnail, contentDescription = "تصویر هدف ${index + 1}", modifier = Modifier.fillMaxSize().padding(3.dp))
                else Text("◷", color = Blue, fontSize = 22.sp)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(if (step.isDelay) "${index + 1}. مکث" else "${index + 1}. هدف تصویری", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    if (step.isDelay) "${step.delayMs} ms" else "${thumbnail?.let { "${it.width}×${it.height}" } ?: "تصویر"} px",
                    color = Muted,
                    fontSize = 11.sp
                )
                Text(if (step.isDelay) "مکث مستقل" else "پیش از لمس: ${step.delayMs} ms", color = if (selected) Blue else Muted, fontSize = 10.sp)
            }
            TextButton(onClick = { confirmDelete = true }, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
                Text("×", color = Color(0xFFFF8294), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (selected) {
            HorizontalDivider(color = Color(0xFF35495B), modifier = Modifier.padding(vertical = 6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (step.isDelay) "مدت" else "مکث پیش از اجرا", color = Muted, fontSize = 10.sp)
                BasicTextField(
                    value = delayText,
                    onValueChange = { delayText = it.filter(Char::isDigit).take(6) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center),
                    modifier = Modifier.width(68.dp).background(Color(0xFF0A121C), RoundedCornerShape(7.dp)).padding(horizontal = 7.dp, vertical = 6.dp)
                )
                Text("ms", color = Muted, fontSize = 10.sp)
                TextButton(onClick = { onUpdateDelay(delayText.toLongOrNull() ?: step.delayMs) }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) { Text("ذخیره", fontSize = 10.sp) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { onMove(-1) }, enabled = index > 0, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("↑", fontSize = 17.sp) }
                TextButton(onClick = { onMove(1) }, enabled = index < MacroStore.steps.lastIndex, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("↓", fontSize = 17.sp) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                if (!step.isDelay) {
                    TextButton(onClick = onReplace, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("جایگزینی", fontSize = 9.sp) }
                    TextButton(onClick = onTest, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("تست", fontSize = 9.sp) }
                    TextButton(onClick = onClickTest, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("تست + لمس", fontSize = 9.sp) }
                }
                TextButton(onClick = onCopy, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("کپی", fontSize = 9.sp) }
                TextButton(onClick = onDelay, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("+ مکث", fontSize = 9.sp) }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text(if (step.isDelay) "حذف این اکشن؟" else "حذف این تصویر؟") },
        text = { Text("فقط همین مورد از فهرست حذف می‌شود.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("حذف") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } }
    )
}
