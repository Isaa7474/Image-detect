package app.imagedetect

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object AppLanguage {
    private val english = mapOf(
        "تنظیمات" to "Settings", "وضعیت" to "Status", "کنترل ماکرو" to "Macro controls",
        "اشتراک صفحه" to "Share screen", "باز کردن تنظیمات دسترسی‌پذیری" to "Open accessibility settings",
        "ویرایش اسکریپت" to "Edit script", "ذخیره" to "Save", "افزودن اکشن" to "Add action",
        "چسباندن اکشن" to "Paste action", "تنظیمات هوشمند" to "Smart settings",
        "حداقل شباهت هدف" to "Minimum match", "مهلت جست‌وجوی هر تصویر" to "Search time per image",
        "فاصلهٔ بررسی تصویر" to "Image check interval", "پس از هر بررسی؛ زمان پردازش جداگانه اضافه می‌شود." to "Pause after each check; processing time is additional.",
        "اندازهٔ کادر تصویر" to "Image box size", "عرض (px)" to "Width (px)", "ارتفاع (px)" to "Height (px)",
        "اعمال" to "Apply", "تعداد تکرار" to "Repeat count", "۰ یعنی بی‌نهایت" to "0 means unlimited",
        "تعداد تکرار · صفر برای بی‌نهایت" to "Repeat count · 0 means unlimited",
        "افزودن مکث ۵۰۰ میلی‌ثانیه" to "Add 500 ms delay", "اعمال اندازهٔ کادر" to "Apply image size",
        "اکشن‌های ضبط‌شده" to "Recorded actions", "● ضبط لمس" to "● Record taps",
        "هدف از تصویر زنده" to "Target from live screen", "ذخیرهٔ نام و توضیح" to "Save name and description",
        "نام اسکریپت" to "Script name", "توضیح" to "Description", "بستن" to "Close",
        "افزودن اکشن" to "Add action", "●  ضبط لمس‌ها" to "● Record taps",
        "▣  هدف از تصویر فعلی" to "▣ Target from current screen", "◷  افزودن مکث" to "◷ Add delay",
        "افزودن مکث" to "Add delay", "میلی‌ثانیه" to "milliseconds", "افزودن" to "Add",
        "انصراف" to "Cancel", "حذف" to "Delete", "حذف همه" to "Delete all",
        "خالی" to "Empty", "تأخیر" to "Delay", "ذخیرهٔ همین فریم" to "Save this frame",
        "لغو" to "Cancel", "جای‌گذاری روی تصویر زنده" to "Replace from live screen",
        "اندازهٔ نمونهٔ تصویر" to "Image sample size", "انتخاب" to "Select", "انتخاب‌شده" to "Selected",
        "جایگزینی" to "Replace", "حلقهٔ اسکریپت" to "Script loop", "تکرار" to "Repeat",
        "در حال ضبط" to "Recording", "مکث شده" to "Paused", "در حال اجرا" to "Running",
        "آماده" to "Ready", "آماده‌سازی لازم است" to "Setup required"
        ,"IMAGE DETECT" to "IMAGE DETECT", "کنترل ضبط و اجرای ماکرو" to "Macro recording and playback",
        "‹  قبلی" to "‹ Previous", "بعدی  ›" to "Next ›", "■  پایان ضبط" to "■ Stop recording",
        "●  ضبط اکشن" to "● Record action", "▶  ادامه" to "▶ Resume", "▶  شروع ماکرو" to "▶ Start macro",
        "Ⅱ  مکث" to "Ⅱ Pause", "■  توقف ماکرو" to "■ Stop macro", "جست‌وجوی تصویر" to "Image search",
        "آستانهٔ تطبیق تصویر هنگام اجرا" to "Image match threshold", "مهلت پیدا کردن هر هدف" to "Time limit per target",
        "افزودن اکشن" to "Add action", "مجموع اکشن‌ها" to "Total actions", "نام اسکریپت" to "Script name",
        "توضیح" to "Description", "تأخیر" to "Delay", "کادر فعلی:" to "Current box:",
        "این اندازه برای لمس‌های ضبط‌شدهٔ بعدی استفاده می‌شود." to "Used for future recorded taps.",
        "اندازهٔ ۱۶ تا ۵۱۲ پیکسل پذیرفته می‌شود؛ کادر جایگزینی را هم می‌توانید جداگانه تغییر دهید." to "Allowed size: 16–512 px. Replacement size can be adjusted separately.",
        "برای ساخت اکشن، گزینهٔ «افزودن اکشن» را بزنید." to "Choose Add action to create an action.",
        "خالی" to "Empty", "مکث دستی" to "Manual delay", "اکشن تأخیر" to "Delay action",
        "تصویر" to "Image", "تست تطبیق" to "Test match", "تست + لمس" to "Test + tap",
        "مشاهدهٔ فریم کامل" to "View full captured frame", "دایرهٔ قرمز، محل لمسی است که ضبط شده" to "Red circle marks the recorded touch",
        "فریم کامل هنوز آماده نیست" to "The captured frame is not ready yet", "نمایش فریم ضبط‌شده ناموفق بود" to "Could not show the captured frame",
        "کپی" to "Copy", "+ مکث" to "+ Delay", "حذف این اکشن؟" to "Delete this action?",
        "حذف این تصویر؟" to "Delete this image?", "فقط همین مورد از فهرست حذف می‌شود." to "Only this item will be removed.",
        "کپی اکشن انتخاب‌شده" to "Copy selected action", "حذف همهٔ اکشن‌ها" to "Delete all actions",
        "مکث پیش از اجرا" to "Delay before run", "مدت" to "Duration", "مکث مستقل" to "Standalone pause",
        "بین هر بررسی تصویر حداقل ۳۵۰ میلی‌ثانیه مکث است؛ زمان پردازش هم اضافه می‌شود." to "Each image check is followed by a 350 ms pause, plus processing time.",
        "حذف همهٔ اکشن‌ها؟" to "Delete all actions?", "تعداد اجرا (۰ = بی‌نهایت)" to "Run count (0 = unlimited)",
        "در صورت پیدا نشدن هدف تا پایان مهلت، ماکرو متوقف می‌شود و بهترین شباهت گزارش می‌شود." to "If a target is not found in time, the macro stops and reports the best match.",
        "اجرای ماکرو از اکشن انتخاب‌شده آغاز می‌شود. برای هر تصویر تا" to "Macro starts from the selected action and searches each image for up to",
        "حداقل شباهت" to "Minimum match", "مهلت جست‌وجو" to "Search time",
        "تنظیمات" to "Settings", "ضبط لمس‌ها" to "Record taps", "هدف از تصویر فعلی" to "Target from current screen",
        "در حال ضبط" to "Recording", "مکث شده" to "Paused", "در حال اجرا" to "Running",
        "آماده" to "Ready", "آماده‌سازی لازم است" to "Setup required",
        "مجوز اشتراک‌گذاری صفحه رد شد" to "Screen-sharing permission was denied",
        "ابتدا Accessibility را در تنظیمات فعال کنید" to "Enable Accessibility in Settings first",
        "برای افزودن هدف، اشتراک‌گذاری صفحه را فعال کنید" to "Enable screen sharing to add a target",
        "یک تصویر برای شروع انتخاب کنید" to "Select an image to start",
        "اسکریپت من" to "My script",
        "برای شروع، مجوزهای لازم را فعال کنید" to "Enable the required permissions to begin",
        "اشتراک‌گذاری صفحه فعال نیست یا هنوز فریمی نرسیده" to "Screen sharing is off or no frame has arrived yet",
        "تصویر زنده دریافت شد؛ آمادهٔ ضبط" to "Live image received; ready to record",
        "اشتراک‌گذاری صفحه متوقف شد" to "Screen sharing stopped",
        "اجرای ماکرو متوقف شد" to "Macro stopped", "اجرای ماکرو مکث شد" to "Macro paused",
        "اجرای ماکرو ادامه یافت" to "Macro resumed", "اجرای ماکرو تمام شد" to "Macro finished",
        "اکشن کپی شد" to "Action copied", "اکشن حذف شد" to "Action deleted", "اسکریپت ذخیره شد" to "Script saved",
        "برای شروع یا پایان ضبط لمس‌ها" to "Start or stop tap recording", "شروع یا ادامهٔ ماکرو" to "Start or resume macro",
        "مکث ماکرو" to "Pause macro", "توقف ماکرو" to "Stop macro", "انتخاب اکشن قبلی" to "Select previous action",
        "انتخاب اکشن بعدی" to "Select next action", "بستن پنل شناور" to "Close floating panel",
        "ویرایش اسکریپت" to "Edit script", "جایگزینی تصویر انتخاب‌شده" to "Replace selected image",
        "ابتدا یک تصویر را انتخاب کنید" to "Select an image first",
        "تنظیمات روی بازی" to "Settings over game", "توضیح (اختیاری)" to "Description (optional)",
        "فهرست ضبط‌شده بالاتر از این بخش قرار دارد." to "Recorded actions are listed above.",
        "هنوز اکشنی ضبط نشده است." to "No actions recorded yet.", "هدف تصویری" to "Image target",
        "کادر: " to "Box: ", " نقطهٔ لمس قرمز" to " · red dot marks tap",
        "بازی پشت این پنجره زنده می‌ماند؛ کادر را روی هدف بکشید." to "The game remains live behind this panel. Drag the box over the target.",
        "فریم تازه نرسیده؛ اشتراک‌گذاری صفحه را بررسی کنید" to "No fresh frame; check screen sharing",
        "کادر جای‌گذاری زنده روی بازی باز شد" to "Live replacement box opened over the game",
        "تصویر زنده جایگزین شد" to "Live image replaced", "ضبط روشن است؛ روی صفحه لمس کنید" to "Recording is on; tap the screen",
        "ضبط متوقف شد" to "Recording stopped", "اکشن چسبانده شد" to "Action pasted",
        "هدف تصویری اضافه شد" to "Image target added", "فریم زنده آماده نیست؛ اشتراک‌گذاری صفحه را بررسی کنید" to "Live frame is not ready; check screen sharing",
        "پنجرهٔ تنظیمات شناور باز نشد؛ دسترس‌پذیری را بررسی کنید" to "Floating settings did not open; check Accessibility",
        "ویرایش روی بازی باز نشد؛ دسترس‌پذیری را بررسی کنید" to "Could not open the overlay; check Accessibility",
        "اسکرین‌شات آماده نیست؛ مجوز صفحه را بررسی کنید" to "Screenshot is not ready; check screen permission",
        "تصویر فعلی برای مقایسه در دسترس نیست" to "Current image is not available for comparison",
        "ابتدا Accessibility را فعال کنید" to "Enable Accessibility first", "کادر: " to "Box: ",
        "این اندازه برای لمس‌های ضبط‌شدهٔ بعدی استفاده می‌شود." to "Used for future recorded taps.",
        "نام اسکریپت" to "Script name", "توضیح (اختیاری)" to "Description (optional)",
        "تصویر هدف" to "Image target", "تأخیر" to "Delay", "مکث دستی" to "Manual delay",
        "آستانهٔ تطبیق هدف" to "Target match threshold", "مهلت جست‌وجوی هر تصویر" to "Search time per image",
        "باز کردن کنترل‌های ماکرو" to "Open macro controls", "بستن منوی ماکرو" to "Close macro menu",
        "بستن پنل شناور" to "Close floating panel", "توقف ضبط" to "Stop recording", "شروع ضبط" to "Start recording",
        "اجرا از تصویر انتخاب‌شده آغاز می‌شود" to "Playback starts from the selected image",
        "Allow restricted settings" to "Allow restricted settings",
        "ضبط" to "Record", "اجرا" to "Run", "مکث" to "Pause", "توقف" to "Stop", "قبلی" to "Previous", "بعدی" to "Next",
        "بستن پنل شناور" to "Close floating panel", "ماکرو در حال اجرا؛ باز کردن کنترل‌ها" to "Macro running; open controls",
        "ماکرو مکث شده؛ باز کردن کنترل‌ها" to "Macro paused; open controls", "ضبط در جریان؛ باز کردن کنترل‌ها" to "Recording; open controls",
        "منوی شناور آماده است؛ لمس هنگام ضبط ثبت و عبور داده می‌شود" to "Floating menu ready; taps are recorded and passed through",
        "لایهٔ ثبت لمس نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Tap-capture layer did not appear; restart the Accessibility service",
        "منوی شناور نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Floating menu did not appear; restart the Accessibility service",
        "لایهٔ ثبت لمس آماده نیست؛ Accessibility را دوباره روشن کنید" to "Tap-capture layer is not ready; restart Accessibility",
        "تصویر صفحه نرسیده؛ ابتدا اشتراک‌گذاری را فعال کنید" to "No screen image yet; start screen sharing",
        "لمس دریافت شد اما به برنامهٔ زیرین فرستاده نشد" to "Tap was captured but not passed to the underlying app",
        "اندروید لمس را لغو کرد" to "Android cancelled the tap", "اندروید لمس را نپذیرفت" to "Android rejected the tap",
        "لمس دیده شد اما اسکرین‌شات آماده نیست" to "Tap was seen, but the screenshot is not ready",
        "گرفتن تصویر ناموفق بود؛ دوباره اشتراک‌گذاری را شروع کنید" to "Could not capture the image; restart screen sharing",
        "در انتظار اولین فریم از صفحهٔ اشتراکی..." to "Waiting for the first shared-screen frame...",
        "نمونهٔ واضح‌تری ثبت کنید" to "Record a clearer sample", "ابتدا یک تصویر برای شروع انتخاب کنید" to "Select an image to start",
        "ماکرو از ابتدا تکرار می‌شود" to "Macro repeats from the beginning", "ماکرو از ابتدا تکرار نمی‌شود" to "Macro will not repeat"
        ,"مجوز اشتراک‌گذاری صفحه دریافت نشد" to "Screen-sharing permission was not received",
        "منوی شناور توسط اندروید نمایش داده نشد" to "Android did not display the floating menu",
        "تصویر صفحه نرسیده؛ ابتدا اشتراک‌گذاری را فعال کنید" to "No screen frame yet; enable screen sharing first",
        "فریم زنده دریافت نشد؛ اشتراک‌گذاری صفحه را بررسی کنید" to "No live frame arrived; check screen sharing",
        "تصویر هدف قابل تطبیق نیست؛ نمونهٔ واضح‌تری ثبت کنید" to "Could not match the target; record a clearer sample",
        "حلقهٔ ماکرو ادامه دارد" to "Macro is repeating", "اجرای لمس" to "Tap action",
        "در حال انتظار برای ادامه" to "Waiting to resume",
        "منوی شناور نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Floating menu did not appear; restart the Accessibility service",
        "مقدار مکث (میلی‌ثانیه)" to "Delay (milliseconds)", "＋  افزودن مکث" to "＋ Add delay",
        "✓  اعمال اندازهٔ کادر" to "✓ Apply image size", "مکث پیش از اجرا (ms)" to "Delay before action (ms)",
        "برنامهٔ مقصد را باز کنید و ضبط را از روی آن شروع کنید" to "Open the target app and start recording from it",
        "ابتدا برنامهٔ موردنظر را باز کنید" to "Open the target app first",
        "ضبط روشن است؛ فقط لمس‌های برنامهٔ مقصد ثبت می‌شود" to "Recording; only taps in the target app are saved",
        "ضبط روشن می‌شود؛ لمس دکمهٔ شروع ثبت نمی‌شود" to "Recording is arming; the start-button tap is ignored",
        "ضبط آماده است؛ برای ثبت لمس‌های بازی پنجره را ببندید" to "Recording is ready; close this panel to capture game taps",
        "کادر جایگزینی باز شد؛ ناحیه را روی تصویر انتخاب کنید" to "Replacement box opened; select an area in the image",
        "کادر جایگزینی باز شد" to "Replacement box opened",
        "هدف‌های تازه خاکستری ذخیره شوند: روشن" to "Save new targets in grayscale: On",
        "هدف‌های تازه خاکستری ذخیره شوند: خاموش" to "Save new targets in grayscale: Off",
        "خاکستری در برابر تغییر رنگ مقاوم‌تر است؛ حالت رنگی برای هدف‌های مشابهِ رنگ‌متفاوت دقیق‌تر است." to "Grayscale is more robust to color changes; color mode is more precise for similar targets that differ by color."
    )

    private val russian = mapOf(
        "تنظیمات" to "Настройки", "وضعیت" to "Статус", "کنترل ماکرو" to "Управление макросом",
        "اشتراک صفحه" to "Показать экран", "باز کردن تنظیمات دسترسی‌پذیری" to "Настройки специальных возможностей",
        "ویرایش اسکریپت" to "Изменить сценарий", "ذخیره" to "Сохранить", "افزودن اکشن" to "Добавить действие",
        "چسباندن اکشن" to "Вставить действие", "تنظیمات هوشمند" to "Интеллектуальные настройки",
        "حداقل شباهت هدف" to "Минимальное совпадение", "مهلت جست‌وجوی هر تصویر" to "Время поиска изображения",
        "اندازهٔ کادر تصویر" to "Размер области изображения", "عرض (px)" to "Ширина (пикс.)", "ارتفاع (px)" to "Высота (пикс.)",
        "اعمال" to "Применить", "تعداد تکرار" to "Количество повторов", "۰ یعنی بی‌نهایت" to "0 — без ограничений",
        "تعداد تکرار · صفر برای بی‌نهایت" to "Повторы · 0 — без ограничений",
        "افزودن مکث ۵۰۰ میلی‌ثانیه" to "Добавить паузу 500 мс", "اعمال اندازهٔ کادر" to "Применить размер",
        "اکشن‌های ضبط‌شده" to "Записанные действия", "● ضبط لمس" to "● Запись касаний",
        "هدف از تصویر زنده" to "Цель с текущего экрана", "ذخیرهٔ نام و توضیح" to "Сохранить имя и описание",
        "نام اسکریپت" to "Название сценария", "توضیح" to "Описание", "بستن" to "Закрыть",
        "●  ضبط لمس‌ها" to "● Записать касания", "▣  هدف از تصویر فعلی" to "▣ Цель с экрана",
        "◷  افزودن مکث" to "◷ Добавить паузу", "افزودن مکث" to "Добавить паузу",
        "میلی‌ثانیه" to "мс", "افزودن" to "Добавить", "انصراف" to "Отмена",
        "حذف" to "Удалить", "حذف همه" to "Удалить все", "خالی" to "Пусто",
        "تأخیر" to "Задержка", "ذخیرهٔ همین فریم" to "Сохранить этот кадр", "لغو" to "Отмена",
        "جای‌گذاری روی تصویر زنده" to "Замена на текущем экране", "اندازهٔ نمونهٔ تصویر" to "Размер образца",
        "انتخاب" to "Выбрать", "انتخاب‌شده" to "Выбрано", "جایگزینی" to "Заменить",
        "حلقهٔ اسکریپت" to "Повтор сценария", "تکرار" to "Повтор", "در حال ضبط" to "Запись",
        "مکث شده" to "Пауза", "در حال اجرا" to "Выполняется", "آماده" to "Готово",
        "آماده‌سازی لازم است" to "Требуется настройка"
        ,"IMAGE DETECT" to "IMAGE DETECT", "کنترل ضبط و اجرای ماکرو" to "Запись и запуск макроса",
        "‹  قبلی" to "‹ Назад", "بعدی  ›" to "Далее ›", "■  پایان ضبط" to "■ Остановить запись",
        "●  ضبط اکشن" to "● Записать действие", "▶  ادامه" to "▶ Продолжить", "▶  شروع ماکرو" to "▶ Запустить макрос",
        "Ⅱ  مکث" to "Ⅱ Пауза", "■  توقف ماکرو" to "■ Остановить макрос", "جست‌وجوی تصویر" to "Поиск изображения",
        "آستانهٔ تطبیق تصویر هنگام اجرا" to "Порог совпадения изображения", "مهلت پیدا کردن هر هدف" to "Время поиска цели",
        "فاصلهٔ بررسی تصویر" to "Интервал проверки изображения", "پس از هر بررسی؛ زمان پردازش جداگانه اضافه می‌شود." to "Пауза после каждой проверки; время обработки добавляется отдельно.",
        "مجموع اکشن‌ها" to "Всего действий", "کادر فعلی:" to "Текущая область:",
        "این اندازه برای لمس‌های ضبط‌شدهٔ بعدی استفاده می‌شود." to "Используется для следующих записанных касаний.",
        "اندازهٔ ۱۶ تا ۵۱۲ پیکسل پذیرفته می‌شود؛ کادر جایگزینی را هم می‌توانید جداگانه تغییر دهید." to "Допустимый размер: 16–512 пикс. Размер замены можно изменить отдельно.",
        "برای ساخت اکشن، گزینهٔ «افزودن اکشن» را بزنید." to "Нажмите «Добавить действие», чтобы создать действие.",
        "مکث دستی" to "Ручная пауза", "اکشن تأخیر" to "Действие-пауза", "تصویر" to "Изображение",
        "تست تطبیق" to "Проверить совпадение", "تست + لمس" to "Проверить + касание", "کپی" to "Копировать",
        "مشاهدهٔ فریم کامل" to "Показать полный кадр", "دایرهٔ قرمز، محل لمسی است که ضبط شده" to "Красный круг показывает записанное касание",
        "فریم کامل هنوز آماده نیست" to "Кадр еще не готов", "نمایش فریم ضبط‌شده ناموفق بود" to "Не удалось показать кадр",
        "+ مکث" to "+ Пауза", "حذف این اکشن؟" to "Удалить это действие?", "حذف این تصویر؟" to "Удалить это изображение?",
        "فقط همین مورد از فهرست حذف می‌شود." to "Будет удален только этот элемент.",
        "کپی اکشن انتخاب‌شده" to "Копировать выбранное действие", "حذف همهٔ اکشن‌ها" to "Удалить все действия",
        "مکث پیش از اجرا" to "Пауза перед запуском", "مدت" to "Длительность", "مکث مستقل" to "Отдельная пауза",
        "بین هر بررسی تصویر حداقل ۳۵۰ میلی‌ثانیه مکث است؛ زمان پردازش هم اضافه می‌شود." to "Между проверками изображения пауза минимум 350 мс плюс время обработки.",
        "حذف همهٔ اکشن‌ها؟" to "Удалить все действия?", "تعداد اجرا (۰ = بی‌نهایت)" to "Запуски (0 = без ограничений)",
        "در صورت پیدا نشدن هدف تا پایان مهلت، ماکرو متوقف می‌شود و بهترین شباهت گزارش می‌شود." to "Если цель не найдена вовремя, макрос остановится и покажет лучшее совпадение.",
        "حداقل شباهت" to "Минимальное совпадение", "مهلت جست‌وجو" to "Время поиска",
        "ضبط لمس‌ها" to "Запись касаний", "هدف از تصویر فعلی" to "Цель с текущего экрана",
        "مجوز اشتراک‌گذاری صفحه رد شد" to "Разрешение на показ экрана отклонено",
        "ابتدا Accessibility را در تنظیمات فعال کنید" to "Сначала включите специальные возможности в настройках",
        "برای افزودن هدف، اشتراک‌گذاری صفحه را فعال کنید" to "Включите показ экрана, чтобы добавить цель",
        "یک تصویر برای شروع انتخاب کنید" to "Выберите изображение для начала",
        "اسکریپت من" to "Мой сценарий",
        "برای شروع، مجوزهای لازم را فعال کنید" to "Для начала включите необходимые разрешения",
        "اشتراک‌گذاری صفحه فعال نیست یا هنوز فریمی نرسیده" to "Показ экрана выключен или кадр еще не получен",
        "تصویر زنده دریافت شد؛ آمادهٔ ضبط" to "Изображение получено; можно записывать",
        "اشتراک‌گذاری صفحه متوقف شد" to "Показ экрана остановлен",
        "اجرای ماکرو متوقف شد" to "Макрос остановлен", "اجرای ماکرو مکث شد" to "Макрос приостановлен",
        "اجرای ماکرو ادامه یافت" to "Макрос продолжен", "اجرای ماکرو تمام شد" to "Макрос завершен",
        "اکشن کپی شد" to "Действие скопировано", "اکشن حذف شد" to "Действие удалено", "اسکریپت ذخیره شد" to "Сценарий сохранен",
        "شروع یا پایان ضبط لمس‌ها" to "Начать или закончить запись касаний", "شروع یا ادامهٔ ماکرو" to "Запустить или продолжить макрос",
        "مکث ماکرو" to "Приостановить макрос", "توقف ماکرو" to "Остановить макрос", "انتخاب اکشن قبلی" to "Предыдущее действие",
        "انتخاب اکشن بعدی" to "Следующее действие", "بستن پنل شناور" to "Закрыть плавающую панель",
        "جایگزینی تصویر انتخاب‌شده" to "Заменить выбранное изображение", "ابتدا یک تصویر را انتخاب کنید" to "Сначала выберите изображение",
        "تنظیمات روی بازی" to "Настройки поверх игры", "توضیح (اختیاری)" to "Описание (необязательно)",
        "فهرست ضبط‌شده بالاتر از این بخش قرار دارد." to "Записанные действия находятся выше.",
        "هنوز اکشنی ضبط نشده است." to "Действий пока нет.", "هدف تصویری" to "Цель изображения",
        "کادر: " to "Область: ", " نقطهٔ لمس قرمز" to " · красная точка — касание",
        "بازی پشت این پنجره زنده می‌ماند؛ کادر را روی هدف بکشید." to "Игра остается активной. Перетащите рамку на цель.",
        "فریم تازه نرسیده؛ اشتراک‌گذاری صفحه را بررسی کنید" to "Новый кадр не получен; проверьте показ экрана",
        "کادر جای‌گذاری زنده روی بازی باز شد" to "Область замены открыта поверх игры",
        "تصویر زنده جایگزین شد" to "Изображение заменено", "ضبط روشن است؛ روی صفحه لمس کنید" to "Запись включена; коснитесь экрана",
        "ضبط متوقف شد" to "Запись остановлена", "اکشن چسبانده شد" to "Действие вставлено",
        "هدف تصویری اضافه شد" to "Цель изображения добавлена", "فریم زنده آماده نیست؛ اشتراک‌گذاری صفحه را بررسی کنید" to "Кадр не готов; проверьте показ экрана",
        "پنجرهٔ تنظیمات شناور باز نشد؛ دسترس‌پذیری را بررسی کنید" to "Не удалось открыть настройки; проверьте специальные возможности",
        "ویرایش روی بازی باز نشد؛ دسترس‌پذیری را بررسی کنید" to "Не удалось открыть панель; проверьте специальные возможности",
        "اسکرین‌شات آماده نیست؛ مجوز صفحه را بررسی کنید" to "Снимок не готов; проверьте разрешение на экран",
        "تصویر فعلی برای مقایسه در دسترس نیست" to "Текущее изображение недоступно для сравнения",
        "ابتدا Accessibility را فعال کنید" to "Сначала включите специальные возможности",
        "این اندازه برای لمس‌های ضبط‌شدهٔ بعدی استفاده می‌شود." to "Используется для следующих записанных касаний.",
        "آستانهٔ تطبیق هدف" to "Порог совпадения", "باز کردن کنترل‌های ماکرو" to "Открыть управление макросом",
        "بستن منوی ماکرو" to "Закрыть меню макроса", "توقف ضبط" to "Остановить запись", "شروع ضبط" to "Начать запись",
        "Allow restricted settings" to "Разрешить ограниченные настройки",
        "ضبط" to "Запись", "اجرا" to "Запуск", "مکث" to "Пауза", "توقف" to "Стоп", "قبلی" to "Назад", "بعدی" to "Далее",
        "بستن پنل شناور" to "Закрыть плавающую панель", "ماکرو در حال اجرا؛ باز کردن کنترل‌ها" to "Макрос выполняется; открыть управление",
        "ماکرو مکث شده؛ باز کردن کنترل‌ها" to "Макрос на паузе; открыть управление", "ضبط در جریان؛ باز کردن کنترل‌ها" to "Запись; открыть управление",
        "منوی شناور آماده است؛ لمس هنگام ضبط ثبت و عبور داده می‌شود" to "Плавающее меню готово; касания записываются и передаются приложению",
        "لایهٔ ثبت لمس نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Слой записи касаний не появился; перезапустите специальные возможности",
        "منوی شناور نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Плавающее меню не появилось; перезапустите специальные возможности",
        "لایهٔ ثبت لمس آماده نیست؛ Accessibility را دوباره روشن کنید" to "Слой записи не готов; перезапустите специальные возможности",
        "تصویر صفحه نرسیده؛ ابتدا اشتراک‌گذاری را فعال کنید" to "Кадр экрана не получен; включите показ экрана",
        "لمس دریافت شد اما به برنامهٔ زیرین فرستاده نشد" to "Касание записано, но не передано приложению",
        "اندروید لمس را لغو کرد" to "Android отменил касание", "اندروید لمس را نپذیرفت" to "Android не принял касание",
        "لمس دیده شد اما اسکرین‌شات آماده نیست" to "Касание обнаружено, но снимок экрана не готов",
        "گرفتن تصویر ناموفق بود؛ دوباره اشتراک‌گذاری را شروع کنید" to "Не удалось получить изображение; перезапустите показ экрана",
        "در انتظار اولین فریم از صفحهٔ اشتراکی..." to "Ожидание первого кадра с экрана...",
        "نمونهٔ واضح‌تری ثبت کنید" to "Запишите более четкий образец"
        ,"مجوز اشتراک‌گذاری صفحه دریافت نشد" to "Разрешение на показ экрана не получено",
        "منوی شناور توسط اندروید نمایش داده نشد" to "Android не показал плавающее меню",
        "تصویر صفحه نرسیده؛ ابتدا اشتراک‌گذاری را فعال کنید" to "Кадр не получен; сначала включите показ экрана",
        "فریم زنده دریافت نشد؛ اشتراک‌گذاری صفحه را بررسی کنید" to "Кадр не получен; проверьте показ экрана",
        "تصویر هدف قابل تطبیق نیست؛ نمونهٔ واضح‌تری ثبت کنید" to "Не удалось сопоставить цель; запишите более четкий образец",
        "حلقهٔ ماکرو ادامه دارد" to "Макрос повторяется",
        "منوی شناور نمایش داده نشد؛ سرویس Accessibility را دوباره روشن کنید" to "Плавающее меню не появилось; перезапустите специальные возможности",
        "مقدار مکث (میلی‌ثانیه)" to "Пауза (миллисекунды)", "＋  افزودن مکث" to "＋ Добавить паузу",
        "✓  اعمال اندازهٔ کادر" to "✓ Применить размер рамки", "مکث پیش از اجرا (ms)" to "Пауза перед действием (мс)",
        "برنامهٔ مقصد را باز کنید و ضبط را از روی آن شروع کنید" to "Откройте целевое приложение и начните запись в нем",
        "ابتدا برنامهٔ موردنظر را باز کنید" to "Сначала откройте целевое приложение",
        "ضبط روشن است؛ فقط لمس‌های برنامهٔ مقصد ثبت می‌شود" to "Запись включена; сохраняются касания только в целевом приложении",
        "ضبط روشن می‌شود؛ لمس دکمهٔ شروع ثبت نمی‌شود" to "Запись запускается; касание кнопки старта игнорируется",
        "ضبط آماده است؛ برای ثبت لمس‌های بازی پنجره را ببندید" to "Запись готова; закройте панель для записи касаний в игре",
        "کادر جایگزینی باز شد؛ ناحیه را روی تصویر انتخاب کنید" to "Рамка замены открыта; выберите область на изображении",
        "کادر جایگزینی باز شد" to "Рамка замены открыта",
        "هدف‌های تازه خاکستری ذخیره شوند: روشن" to "Сохранять новые цели в оттенках серого: Вкл.",
        "هدف‌های تازه خاکستری ذخیره شوند: خاموش" to "Сохранять новые цели в оттенках серого: Выкл.",
        "خاکستری در برابر تغییر رنگ مقاوم‌تر است؛ حالت رنگی برای هدف‌های مشابهِ رنگ‌متفاوت دقیق‌تر است." to "Оттенки серого устойчивее к смене цвета; цветной режим точнее различает похожие цели разных цветов."
    )

    var current by mutableStateOf("fa")
        private set

    fun initialize(context: Context) {
        val default = when (context.resources.configuration.locales[0]?.language) {
            "en" -> "en"
            "ru" -> "ru"
            else -> "fa"
        }
        current = context.getSharedPreferences("macro", Context.MODE_PRIVATE).getString("language", default) ?: default
    }

    fun select(context: Context, language: String) {
        current = language
        context.getSharedPreferences("macro", Context.MODE_PRIVATE).edit().putString("language", language).apply()
        MacroAccessibilityService.instance?.refreshFloatingMenu()
    }

    fun translate(value: String): String {
        if (current == "fa") return value
        val result = when (current) {
            "en" -> english[value]
            "ru" -> russian[value]
            else -> null
        }
        return result ?: translateDynamic(value)
    }

    private fun translateDynamic(value: String): String {
        val language = current
        val statusBlock = Regex("وضعیت: ([^\\n]+) · مرحله (\\d+)/(\\d+)\\n([\\s\\S]+)").matchEntire(value)
        if (statusBlock != null) {
            val heading = if (language == "en") "Status: ${translate(statusBlock.groupValues[1])} · Step ${statusBlock.groupValues[2]}/${statusBlock.groupValues[3]}"
                else "Статус: ${translate(statusBlock.groupValues[1])} · Этап ${statusBlock.groupValues[2]}/${statusBlock.groupValues[3]}"
            return "$heading\n${translate(statusBlock.groupValues[4])}"
        }
        val match = Regex("(\\d+) تصویر · (\\d+) اکشن").matchEntire(value)
        if (match != null) return if (language == "en") "${match.groupValues[1]} images · ${match.groupValues[2]} actions" else "${match.groupValues[1]} изображений · ${match.groupValues[2]} действий"
        val actionTotal = Regex("مجموع اکشن‌ها: (\\d+)").matchEntire(value)
        if (actionTotal != null) return if (language == "en") "Total actions: ${actionTotal.groupValues[1]}" else "Всего действий: ${actionTotal.groupValues[1]}"
        val runTime = Regex("اجرای ماکرو از اکشن انتخاب‌شده آغاز می‌شود\\. برای هر تصویر تا (\\d+) ثانیه جست‌وجو می‌شود\\.").matchEntire(value)
        if (runTime != null) return if (language == "en") "Macro starts at the selected action and searches each image for up to ${runTime.groupValues[1]} seconds." else "Макрос начнется с выбранного действия и будет искать каждое изображение до ${runTime.groupValues[1]} с."
        val failTarget = Regex("هدف (\\d+) پیدا نشد؛ بهترین شباهت (\\d+)٪ از (\\d+)٪").matchEntire(value)
        if (failTarget != null) return if (language == "en") "Target ${failTarget.groupValues[1]} not found; best match ${failTarget.groupValues[2]}% of ${failTarget.groupValues[3]}%" else "Цель ${failTarget.groupValues[1]} не найдена; лучшее совпадение ${failTarget.groupValues[2]}% из ${failTarget.groupValues[3]}%"
        val unstableTarget = Regex("هدف (\\d+) پایدار نبود؛ تطبیق باید در دو فریم تازه تأیید شود").matchEntire(value)
        if (unstableTarget != null) return if (language == "en") "Target ${unstableTarget.groupValues[1]} was unstable; it must match in two fresh frames" else "Цель ${unstableTarget.groupValues[1]} нестабильна; совпадение должно подтвердиться в двух новых кадрах"
        val matched = Regex("تطبیق (\\d+)٪ · اجرای لمس (\\d+)").matchEntire(value)
        if (matched != null) return if (language == "en") "Matched ${matched.groupValues[1]}% · tapping action ${matched.groupValues[2]}" else "Совпадение ${matched.groupValues[1]}% · касание действия ${matched.groupValues[2]}"
        val matchReport = Regex("تطبیق تصویر: (\\d+)٪").matchEntire(value)
        if (matchReport != null) return if (language == "en") "Image match: ${matchReport.groupValues[1]}%" else "Совпадение изображения: ${matchReport.groupValues[1]}%"
        val tapReport = Regex("تطبیق (\\d+)٪؛ لمس ارسال شد").matchEntire(value)
        if (tapReport != null) return if (language == "en") "Matched ${tapReport.groupValues[1]}%; tap sent" else "Совпадение ${tapReport.groupValues[1]}%; касание отправлено"
        val bestScore = Regex("بهترین شباهت (\\d+)٪ است؛ حد لازم (\\d+)٪").matchEntire(value)
        if (bestScore != null) return if (language == "en") "Best match is ${bestScore.groupValues[1]}%; required ${bestScore.groupValues[2]}%" else "Лучшее совпадение ${bestScore.groupValues[1]}%; требуется ${bestScore.groupValues[2]}%"
        val seconds = Regex("(\\d+) ثانیه").matchEntire(value)
        if (seconds != null) return if (language == "en") "${seconds.groupValues[1]} seconds" else "${seconds.groupValues[1]} с"
        val sample = Regex("نمونهٔ (\\d+×\\d+)px").matchEntire(value)
        if (sample != null) return if (language == "en") "Sample ${sample.groupValues[1]} px" else "Образец ${sample.groupValues[1]} пикс."
        val recordedTap = Regex("لمس ضبط شد · فاصله (\\d+)ms").matchEntire(value)
        if (recordedTap != null) return if (language == "en") "Tap recorded · interval ${recordedTap.groupValues[1]} ms" else "Касание записано · интервал ${recordedTap.groupValues[1]} мс"
        val pause = Regex("(\\d+)\\. مکث · (\\d+) میلی‌ثانیه").matchEntire(value)
        if (pause != null) return if (language == "en") "${pause.groupValues[1]}. Delay · ${pause.groupValues[2]} ms" else "${pause.groupValues[1]}. Пауза · ${pause.groupValues[2]} мс"
        val target = Regex("(\\d+)\\. هدف تصویری(.*)").matchEntire(value)
        if (target != null) return if (language == "en") "${target.groupValues[1]}. Image target${target.groupValues[2]}" else "${target.groupValues[1]}. Цель изображения${target.groupValues[2]}"
        val pauseStep = Regex("(\\d+)\\. مکث").matchEntire(value)
        if (pauseStep != null) return if (language == "en") "${pauseStep.groupValues[1]}. Pause" else "${pauseStep.groupValues[1]}. Пауза"
        val beforeTap = Regex("پیش از لمس: (\\d+) ms").matchEntire(value)
        if (beforeTap != null) return if (language == "en") "Before tap: ${beforeTap.groupValues[1]} ms" else "Перед касанием: ${beforeTap.groupValues[1]} мс"
        val dimensions = Regex("کادر: (\\d+) × (\\d+) px · نقطهٔ لمس قرمز").matchEntire(value)
        if (dimensions != null) return if (language == "en") "Box: ${dimensions.groupValues[1]} × ${dimensions.groupValues[2]} px · red dot marks tap" else "Область: ${dimensions.groupValues[1]} × ${dimensions.groupValues[2]} пикс. · красная точка — касание"
        val currentBox = Regex("کادر فعلی: (\\d+) × (\\d+)px").matchEntire(value)
        if (currentBox != null) return if (language == "en") "Current box: ${currentBox.groupValues[1]} × ${currentBox.groupValues[2]} px" else "Текущая область: ${currentBox.groupValues[1]} × ${currentBox.groupValues[2]} пикс."
        val threshold = Regex("حداقل شباهت: (\\d+)٪").matchEntire(value)
        if (threshold != null) return if (language == "en") "Minimum match: ${threshold.groupValues[1]}%" else "Минимальное совпадение: ${threshold.groupValues[1]}%"
        val timeout = Regex("مهلت جست‌وجو: (\\d+) ثانیه").matchEntire(value)
        if (timeout != null) return if (language == "en") "Search time: ${timeout.groupValues[1]} sec" else "Время поиска: ${timeout.groupValues[1]} с"
        val step = Regex("هدف (\\d+)").matchEntire(value)
        if (step != null) return if (language == "en") "Target ${step.groupValues[1]}" else "Цель ${step.groupValues[1]}"
        if (value == "وضعیت: در حال ضبط" || value.startsWith("وضعیت: در حال ضبط ·")) return value.replace("وضعیت: در حال ضبط", if (language == "en") "Status: Recording" else "Статус: Запись")
        if (value.startsWith("وضعیت: مکث شده")) return value.replace("وضعیت: مکث شده", if (language == "en") "Status: Paused" else "Статус: Пауза")
        if (value.startsWith("وضعیت: در حال اجرا")) return value.replace("وضعیت: در حال اجرا", if (language == "en") "Status: Running" else "Статус: Выполняется")
        if (value.startsWith("وضعیت: آماده")) return value.replace("وضعیت: آماده", if (language == "en") "Status: Ready" else "Статус: Готово")
        return value
    }
}
