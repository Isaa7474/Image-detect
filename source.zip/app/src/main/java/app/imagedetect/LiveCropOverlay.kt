package app.imagedetect

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class LiveCropSelection(
    val frameWidth: Int,
    val frameHeight: Int,
    val centerX: Float,
    val centerY: Float,
    val boxWidth: Float,
    val boxHeight: Float,
    val pointX: Float,
    val pointY: Float
)

class LiveCropOverlay(
    private val service: AccessibilityService,
    frameWidth: Int,
    frameHeight: Int,
    private val initialWidth: Int,
    private val initialHeight: Int,
    private val onSave: (LiveCropSelection) -> Unit,
    private val onCancel: () -> Unit
) {
    private val manager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val frameWidth = frameWidth.coerceAtLeast(1)
    private val frameHeight = frameHeight.coerceAtLeast(1)
    private var root: FrameLayout? = null
    private lateinit var cropView: CropCanvasView

    fun show() {
        if (root != null) return
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        manager.defaultDisplay.getRealMetrics(metrics)
        val overlay = FrameLayout(service).apply {
            isFocusableInTouchMode = true
            layoutDirection = if (AppLanguage.current == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        cropView = CropCanvasView(service, frameWidth, frameHeight, initialWidth, initialHeight)
        overlay.addView(cropView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val title = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = rounded(0xEF101A25.toInt(), 0xFF34495E.toInt(), dp(13))
            isClickable = true
        }
        title.addView(text("جای‌گذاری روی تصویر زنده", 16, Color.WHITE, true))
        title.addView(text("بازی پشت این پنجره زنده می‌ماند؛ کادر را روی هدف بکشید.", 11, 0xFFD2DCE6.toInt(), false))
        overlay.addView(title, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(60), Gravity.TOP).apply {
            leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(24)
        })

        val controls = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = rounded(0xF2111D2A.toInt(), 0xFF34495E.toInt(), dp(16))
            isClickable = true
        }
        controls.addView(text("اندازهٔ نمونهٔ تصویر", 13, Color.WHITE, true))
        val widthInput = editField(MacroStore.patchWidth.toString(), "عرض px")
        val heightInput = editField(MacroStore.patchHeight.toString(), "ارتفاع px")
        val sizeRow = LinearLayout(service).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sizeRow.addView(widthInput, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        sizeRow.addView(heightInput, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })
        sizeRow.addView(button("اعمال", 0xFF334B60.toInt()) {
            cropView.setBoxSize(widthInput.text.toString().toIntOrNull() ?: cropView.boxWidth.roundToInt(), heightInput.text.toString().toIntOrNull() ?: cropView.boxHeight.roundToInt())
            widthInput.setText(cropView.boxWidth.roundToInt().toString())
            heightInput.setText(cropView.boxHeight.roundToInt().toString())
        }, LinearLayout.LayoutParams(dp(68), dp(42)).apply { marginStart = dp(5) })
        controls.addView(sizeRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(5) })
        val dimensions = text("کادر: ${cropView.boxWidth.roundToInt()} × ${cropView.boxHeight.roundToInt()} px · نقطهٔ لمس قرمز", 11, 0xFF7CF5D2.toInt(), false)
        cropView.onSelectionChanged = { selection -> dimensions.text = AppLanguage.translate("کادر: ${selection.boxWidth.roundToInt()} × ${selection.boxHeight.roundToInt()} px · نقطهٔ لمس قرمز") }
        controls.addView(dimensions, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(24)).apply { topMargin = dp(2) })
        val buttonRow = LinearLayout(service).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttonRow.addView(button("لغو", 0xFF303D4A.toInt()) { onCancel() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        buttonRow.addView(button("ذخیرهٔ همین فریم", 0xFF286F63.toInt()) { onSave(cropView.selection()) }, LinearLayout.LayoutParams(0, dp(46), 1.5f).apply { marginStart = dp(4) })
        controls.addView(buttonRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(5) })
        overlay.addView(controls, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            leftMargin = dp(8); rightMargin = dp(8); bottomMargin = dp(26)
        })

        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            manager.addView(overlay, params)
            root = overlay
        } catch (_: WindowManager.BadTokenException) {
            MacroStore.status = "ویرایش روی بازی باز نشد؛ دسترس‌پذیری را بررسی کنید"
        }
    }

    fun dismiss() {
        root?.let { runCatching { manager.removeView(it) } }
        root = null
    }

    fun isShowing() = root != null

    private fun editField(value: String, hintText: String) = EditText(service).apply {
        setText(value)
        hint = hintText
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF8797A8.toInt())
        textSize = 13f
        setSingleLine(true)
        gravity = Gravity.CENTER
        setPadding(dp(7), 0, dp(7), 0)
        background = rounded(0xFF0A131E.toInt(), 0xFF40546A.toInt(), dp(8))
    }

    private fun button(label: String, color: Int, onClick: () -> Unit) = TextView(service).apply {
        text = AppLanguage.translate(label)
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(color, 0xFF536A80.toInt(), dp(10))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(service).apply {
        text = AppLanguage.translate(value)
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int) = (value * service.resources.displayMetrics.density).roundToInt()

    private enum class DragMode { MOVE, RESIZE, POINT }

    private class CropCanvasView(context: Context, private val frameWidth: Int, private val frameHeight: Int, width: Int, height: Int) : View(context) {
        var boxWidth = width.coerceIn(16, frameWidth).toFloat()
            private set
        var boxHeight = height.coerceIn(16, frameHeight).toFloat()
            private set
        private var centerX = frameWidth / 2f
        private var centerY = frameHeight / 2f
        private var pointX = centerX
        private var pointY = centerY
        var onSelectionChanged: ((LiveCropSelection) -> Unit)? = null
        private var dragMode = DragMode.MOVE
        private var lastX = 0f
        private var lastY = 0f
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 35, 234, 184); style = Paint.Style.FILL }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(124, 245, 210); style = Paint.Style.STROKE; strokeWidth = dp(2.5f) }
        private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 94, 113); style = Paint.Style.STROKE; strokeWidth = dp(2.5f) }
        private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        private val scrimPaint = Paint().apply { color = Color.argb(26, 0, 0, 0) }

        init { isClickable = true }

        fun setBoxSize(width: Int, height: Int) {
            boxWidth = width.coerceIn(16, frameWidth).toFloat()
            boxHeight = height.coerceIn(16, frameHeight).toFloat()
            centerX = centerX.coerceIn(boxWidth / 2f, frameWidth - boxWidth / 2f)
            centerY = centerY.coerceIn(boxHeight / 2f, frameHeight - boxHeight / 2f)
            pointX = pointX.coerceIn(centerX - boxWidth / 2f, centerX + boxWidth / 2f)
            pointY = pointY.coerceIn(centerY - boxHeight / 2f, centerY + boxHeight / 2f)
            invalidate()
            onSelectionChanged?.invoke(selection())
        }

        fun selection() = LiveCropSelection(frameWidth, frameHeight, centerX, centerY, boxWidth, boxHeight, pointX, pointY)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), scrimPaint)
            val scale = min(width.toFloat() / frameWidth, height.toFloat() / frameHeight).coerceAtLeast(0.001f)
            val offsetX = (width - frameWidth * scale) / 2f
            val offsetY = (height - frameHeight * scale) / 2f
            val left = offsetX + (centerX - boxWidth / 2f) * scale
            val top = offsetY + (centerY - boxHeight / 2f) * scale
            val right = left + boxWidth * scale
            val bottom = top + boxHeight * scale
            canvas.drawRect(RectF(left, top, right, bottom), fillPaint)
            canvas.drawRect(RectF(left, top, right, bottom), borderPaint)
            canvas.drawCircle(right, bottom, dp(7f), handlePaint)
            val px = offsetX + pointX * scale
            val py = offsetY + pointY * scale
            canvas.drawCircle(px, py, dp(8f), pointPaint)
            canvas.drawLine(px - dp(13f), py, px + dp(13f), py, pointPaint)
            canvas.drawLine(px, py - dp(13f), px, py + dp(13f), pointPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val scale = min(width.toFloat() / frameWidth, height.toFloat() / frameHeight).coerceAtLeast(0.001f)
            val offsetX = (width - frameWidth * scale) / 2f
            val offsetY = (height - frameHeight * scale) / 2f
            val x = (event.x - offsetX) / scale
            val y = (event.y - offsetY) / scale
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = x
                    lastY = y
                    val handleX = centerX + boxWidth / 2f
                    val handleY = centerY + boxHeight / 2f
                    dragMode = when {
                        distance(event.x, event.y, offsetX + pointX * scale, offsetY + pointY * scale) < dp(26f) -> DragMode.POINT
                        abs(event.x - (offsetX + handleX * scale)) < dp(32f) && abs(event.y - (offsetY + handleY * scale)) < dp(32f) -> DragMode.RESIZE
                        else -> DragMode.MOVE
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = x - lastX
                    val dy = y - lastY
                    when (dragMode) {
                        DragMode.POINT -> {
                            pointX = (pointX + dx).coerceIn(centerX - boxWidth / 2f, centerX + boxWidth / 2f)
                            pointY = (pointY + dy).coerceIn(centerY - boxHeight / 2f, centerY + boxHeight / 2f)
                        }
                        DragMode.MOVE -> {
                            val halfX = boxWidth / 2f
                            val halfY = boxHeight / 2f
                            centerX = (centerX + dx).coerceIn(halfX, frameWidth - halfX)
                            centerY = (centerY + dy).coerceIn(halfY, frameHeight - halfY)
                            pointX = (pointX + dx).coerceIn(0f, frameWidth.toFloat())
                            pointY = (pointY + dy).coerceIn(0f, frameHeight.toFloat())
                        }
                        DragMode.RESIZE -> {
                            boxWidth = (boxWidth + dx).coerceIn(16f, frameWidth.toFloat())
                            boxHeight = (boxHeight + dy).coerceIn(16f, frameHeight.toFloat())
                            centerX = centerX.coerceIn(boxWidth / 2f, frameWidth - boxWidth / 2f)
                            centerY = centerY.coerceIn(boxHeight / 2f, frameHeight - boxHeight / 2f)
                            pointX = pointX.coerceIn(centerX - boxWidth / 2f, centerX + boxWidth / 2f)
                            pointY = pointY.coerceIn(centerY - boxHeight / 2f, centerY + boxHeight / 2f)
                        }
                    }
                    lastX = x
                    lastY = y
                    invalidate()
                    onSelectionChanged?.invoke(selection())
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }

        private fun distance(x1: Float, y1: Float, x2: Float, y2: Float) =
            sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))

        private fun dp(value: Float) = value * resources.displayMetrics.density
    }
}
