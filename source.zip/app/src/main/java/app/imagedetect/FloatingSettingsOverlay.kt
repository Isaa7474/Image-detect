package app.imagedetect

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class FloatingSettingsOverlay(
    private val service: AccessibilityService,
    private val onClose: () -> Unit,
    private val onRecord: () -> Unit,
    private val onAddTarget: () -> Unit,
    private val onAddDelay: (Long) -> Unit,
    private val onReplace: (MacroStep) -> Unit,
    private val onTest: (MacroStep, Boolean) -> Unit
) {
    private val manager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var stepList: LinearLayout? = null
    private var stepCount: TextView? = null
    private var recordToggle: TextView? = null
    private var capturePreviewRoot: FrameLayout? = null
    private var capturePreviewBitmap: android.graphics.Bitmap? = null

    fun show() {
        if (root != null) return
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        manager.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val panel = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (AppLanguage.current == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            isClickable = true
            background = rounded(0xF2101433.toInt(), 0xFF5B6CFF.toInt(), dp(20))
            setPadding(dp(13), dp(10), dp(13), dp(10))
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("تنظیمات روی بازی", 18, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(button("بستن", 0xFF314558.toInt()) { onClose() }, LinearLayout.LayoutParams(dp(66), dp(38)))

        val scroll = ScrollView(service).apply { isFillViewport = true }
        val content = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (AppLanguage.current == "fa") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            setPadding(0, dp(4), 0, dp(4))
        }
        val name = editField(AppLanguage.translate(MacroStore.scriptName), "نام اسکریپت")
        val description = editField(MacroStore.scriptDescription, "توضیح (اختیاری)")
        content.addView(text("نام اسکریپت", 12, 0xFFB6C3D0.toInt(), false), marginParams(top = 8))
        content.addView(name, marginParams(top = 4))
        content.addView(text("توضیح", 12, 0xFFB6C3D0.toInt(), false), marginParams(top = 8))
        content.addView(description, marginParams(top = 4))
        content.addView(button("ذخیرهٔ نام و توضیح", 0xFF244D78.toInt()) {
            MacroStore.updateScript(name.text.toString(), description.text.toString())
        }, marginParams(top = 7, height = 40))

        content.addView(text("اکشن‌های ضبط‌شده", 16, Color.WHITE, true), marginParams(top = 15))
        stepCount = text("", 11, 0xFFB6C3D0.toInt(), false)
        content.addView(stepCount, marginParams(top = 3))
        stepList = LinearLayout(service).apply { orientation = LinearLayout.VERTICAL }
        content.addView(stepList, marginParams(top = 6))
        val actionRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 2f
        }
        recordToggle = button(recordLabel(), 0xFF1C3442.toInt()) { onRecord() }
        actionRow.addView(recordToggle, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(4) })
        actionRow.addView(button("هدف از تصویر زنده", 0xFF315B53.toInt()) { onAddTarget() }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(4) })
        content.addView(actionRow, marginParams(top = 8))
        val newDelayInput = editField("500", "مقدار مکث (میلی‌ثانیه)").apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val delayRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        delayRow.addView(newDelayInput, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(7) })
        delayRow.addView(button("＋  افزودن مکث", 0xFF187B70.toInt()) {
            onAddDelay(newDelayInput.text.toString().toLongOrNull()?.coerceIn(0L, 600_000L) ?: 500L)
        }.apply {
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF176E68.toInt(), 0xFF238E80.toInt())).apply {
                cornerRadius = dp(11).toFloat()
                setStroke(dp(1), 0xFF53B7A5.toInt())
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1.25f).apply { marginStart = dp(3) })
        content.addView(delayRow, marginParams(top = 6))

        val widthInput = editField(MacroStore.patchWidth.toString(), "عرض (px)").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val heightInput = editField(MacroStore.patchHeight.toString(), "ارتفاع (px)").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        content.addView(text("اندازهٔ کادر تصویر", 16, Color.WHITE, true), marginParams(top = 18))
        content.addView(text("فهرست ضبط‌شده بالاتر از این بخش قرار دارد.", 11, 0xFFB6C3D0.toInt(), false), marginParams(top = 3))
        val sizeRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            weightSum = 2f
        }
        sizeRow.addView(widthInput, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        sizeRow.addView(heightInput, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })
        content.addView(sizeRow, marginParams(top = 7))
        content.addView(button("✓  اعمال اندازهٔ کادر", 0xFF244D78.toInt()) {
            MacroStore.updatePatchSize(widthInput.text.toString().toIntOrNull() ?: MacroStore.patchWidth, heightInput.text.toString().toIntOrNull() ?: MacroStore.patchHeight)
            widthInput.setText(MacroStore.patchWidth.toString())
            heightInput.setText(MacroStore.patchHeight.toString())
        }.apply {
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF1D4771.toInt(), 0xFF286A9E.toInt())).apply {
                cornerRadius = dp(11).toFloat()
                setStroke(dp(1), 0xFF5A9ED3.toInt())
            }
        }, marginParams(top = 7, height = dp(48)))

        fun grayscaleLabel() = "هدف‌های تازه خاکستری ذخیره شوند: ${if (MacroStore.grayscaleCapture) "روشن" else "خاموش"}"
        lateinit var grayscaleToggle: TextView
        grayscaleToggle = button(grayscaleLabel(), 0xFF344A5D.toInt()) {
            MacroStore.updateGrayscaleCapture(!MacroStore.grayscaleCapture)
            grayscaleToggle.text = AppLanguage.translate(grayscaleLabel())
            grayscaleToggle.background = rounded(if (MacroStore.grayscaleCapture) 0xFF315B53.toInt() else 0xFF344A5D.toInt(), 0xFF536A80.toInt(), dp(10))
            MacroStore.status = if (MacroStore.grayscaleCapture) "هدف‌های تازه خاکستری ذخیره می‌شوند؛ رنگ در امتیاز تطبیق نادیده گرفته می‌شود" else "ذخیرهٔ رنگی برای هدف‌های تازه فعال شد"
        }
        content.addView(grayscaleToggle, marginParams(top = 12, height = dp(44)))
        content.addView(text("خاکستری در برابر تغییر رنگ مقاوم‌تر است؛ حالت رنگی برای هدف‌های مشابهِ رنگ‌متفاوت دقیق‌تر است.", 10, 0xFFB6C3D0.toInt(), false), marginParams(top = 3))

        content.addView(text("تنظیمات هوشمند", 16, Color.WHITE, true), marginParams(top = 18))
        val thresholdLabel = text("حداقل شباهت: ${MacroStore.matchThreshold.toInt()}٪", 12, Color.WHITE, false)
        content.addView(thresholdLabel, marginParams(top = 4))
        content.addView(SeekBar(service).apply {
            max = 45
            progress = (MacroStore.matchThreshold.toInt() - 50).coerceIn(0, 45)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 50
                    thresholdLabel.text = AppLanguage.translate("حداقل شباهت: $value٪")
                    if (fromUser) MacroStore.updateMatchSettings(threshold = value.toFloat())
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }, marginParams(top = 2))
        val timeoutLabel = text("مهلت جست‌وجو: ${MacroStore.searchTimeoutSeconds} ثانیه", 12, Color.WHITE, false)
        content.addView(timeoutLabel, marginParams(top = 4))
        content.addView(SeekBar(service).apply {
            max = 55
            progress = (MacroStore.searchTimeoutSeconds - 5).coerceIn(0, 55)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + 5
                    timeoutLabel.text = AppLanguage.translate("مهلت جست‌وجو: $value ثانیه")
                    if (fromUser) MacroStore.updateMatchSettings(timeoutSeconds = value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }, marginParams(top = 2))
        val repeatCountInput = editField(MacroStore.repeatCount.toString(), "تعداد اجرا (۰ = بی‌نهایت)").apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    s?.toString()?.toIntOrNull()?.let(MacroStore::updateRepeatCount)
                }
                override fun afterTextChanged(s: android.text.Editable?) = Unit
            })
        }
        content.addView(text("تعداد تکرار · صفر برای بی‌نهایت", 12, 0xFFB6C3D0.toInt(), false), marginParams(top = 10))
        content.addView(repeatCountInput, marginParams(top = 4, height = 40))
        content.addView(text(MacroStore.status, 11, 0xFFB6C3D0.toInt(), false), marginParams(top = 8, bottom = 4))
        scroll.addView(content)
        panel.addView(header)
        panel.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val overlay = FrameLayout(service).apply {
            setBackgroundColor(0x38000000)
            isClickable = true
            isFocusableInTouchMode = true
        }
        overlay.addView(panel, FrameLayout.LayoutParams(minOf(width - dp(28), dp(520)), minOf(height - dp(42), dp(820)), Gravity.CENTER))
        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            manager.addView(overlay, params)
            root = overlay
            refreshSteps()
        } catch (_: WindowManager.BadTokenException) {
            MacroStore.status = "پنجرهٔ تنظیمات شناور باز نشد؛ دسترس‌پذیری را بررسی کنید"
        }
    }

    fun refreshSteps() {
        val list = stepList ?: return
        list.removeAllViews()
        val steps = MacroStore.steps.toList()
        stepCount?.text = AppLanguage.translate("${steps.count { !it.isDelay }} تصویر · ${steps.size} اکشن")
        if (steps.isEmpty()) {
            list.addView(text("هنوز اکشنی ضبط نشده است.", 12, 0xFFB6C3D0.toInt(), false), marginParams(bottom = 4))
            return
        }
        steps.forEachIndexed { index, step ->
            val card = LinearLayout(service).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(7), dp(9), dp(7))
                background = rounded(if (step.id == MacroStore.selectedStepId) 0xFF263949.toInt() else 0xFF1A2734.toInt(), 0xFF3B4E61.toInt(), dp(12))
            }
            val label = if (step.isDelay) "${index + 1}. مکث · ${step.delayMs} میلی‌ثانیه" else {
                val image = MacroStore.image(step)
                val dimensions = image?.let { " · ${it.width}×${it.height}px" } ?: ""
                image?.recycle()
                "${index + 1}. هدف تصویری$dimensions"
            }
            val heading = LinearLayout(service).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            if (!step.isDelay) {
                MacroStore.image(step)?.let { bitmap ->
                    heading.addView(ImageView(service).apply {
                        setImageBitmap(bitmap)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = rounded(0xFF101A25.toInt(), 0xFF3B4E61.toInt(), dp(7))
                        clipToOutline = true
                    }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
                }
            }
            heading.addView(text(label, 12, Color.WHITE, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            card.addView(heading)
            if (step.capturePreviewName != null && step.captureX != null && step.captureY != null) {
                card.addView(text("مختصات لمس ثبت‌شده: ${step.captureX.roundToInt()}, ${step.captureY.roundToInt()} px", 10, 0xFFB6C3D0.toInt(), false), marginParams(top = 3))
            }
            val delayInput = editField(step.delayMs.toString(), "ms").apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                gravity = Gravity.CENTER
            }
            val delayEditRow = LinearLayout(service).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            delayEditRow.addView(text("مکث پیش از اجرا (ms)", 10, 0xFFB6C3D0.toInt(), false), LinearLayout.LayoutParams(0, dp(38), 1f))
            delayEditRow.addView(delayInput, LinearLayout.LayoutParams(dp(78), dp(38)).apply { marginStart = dp(4) })
            delayEditRow.addView(button("ذخیره", 0xFF344A5D.toInt()) {
                MacroStore.updateDelay(index, delayInput.text.toString().toLongOrNull() ?: step.delayMs)
                refreshSteps()
            }, LinearLayout.LayoutParams(dp(72), dp(38)).apply { marginStart = dp(5) })
            card.addView(delayEditRow, marginParams(top = 5))
            val controls = LinearLayout(service).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            controls.addView(button(if (step.id == MacroStore.selectedStepId) "انتخاب‌شده" else "انتخاب", 0xFF334B60.toInt()) {
                MacroStore.selectStart(step.id)
                refreshSteps()
            }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(3) })
            if (!step.isDelay) controls.addView(button("جایگزینی", 0xFF315B53.toInt()) { onReplace(step) }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
            controls.addView(button("حذف", 0xFF542C39.toInt()) {
                MacroStore.delete(index)
                refreshSteps()
            }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginStart = dp(3) })
            card.addView(controls, marginParams(top = 5))
            if (!step.isDelay) {
                val tests = LinearLayout(service).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                tests.addView(button("تست تطبیق", 0xFF244D78.toInt()) { onTest(step, false) }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginEnd = dp(3) })
                tests.addView(button("تست + لمس", 0xFF315B53.toInt()) { onTest(step, true) }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginStart = dp(3) })
                card.addView(tests, marginParams(top = 5))
                if (step.capturePreviewName != null) {
                    card.addView(button("مشاهدهٔ فریم کامل", 0xFF38404A.toInt()) { showCapturePreview(step) }, marginParams(top = 5, height = dp(36)))
                }
            }
            list.addView(card, marginParams(bottom = 6))
        }
    }

    fun refreshRecording(recording: Boolean) {
        recordToggle?.text = AppLanguage.translate(recordLabel(recording))
        recordToggle?.background = rounded(if (recording) 0xFF653441.toInt() else 0xFF1C3442.toInt(), 0xFF536A80.toInt(), dp(10))
    }

    fun dismiss() {
        closeCapturePreview()
        root?.let { runCatching { manager.removeView(it) } }
        root = null
        stepList = null
        stepCount = null
        recordToggle = null
    }

    private fun showCapturePreview(step: MacroStep) {
        closeCapturePreview()
        val bitmap = MacroStore.capturePreview(step)
        if (bitmap == null) {
            Toast.makeText(service, AppLanguage.translate("فریم کامل هنوز آماده نیست"), Toast.LENGTH_SHORT).show()
            return
        }
        val preview = FrameLayout(service).apply {
            setBackgroundColor(0xF20A1119.toInt())
            isClickable = true
        }
        preview.addView(ImageView(service).apply {
            setImageBitmap(bitmap)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        preview.addView(text("دایرهٔ قرمز، محل لمسی است که ضبط شده", 14, Color.WHITE, true), FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, dp(50), Gravity.BOTTOM).apply {
            leftMargin = dp(12)
            rightMargin = dp(12)
        })
        preview.addView(button("بستن", 0xFF314558.toInt()) { closeCapturePreview() }, FrameLayout.LayoutParams(dp(78), dp(42), Gravity.TOP or Gravity.RIGHT).apply {
            topMargin = dp(16)
            rightMargin = dp(16)
        })
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        manager.defaultDisplay.getRealMetrics(metrics)
        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT }
        try {
            manager.addView(preview, params)
            capturePreviewRoot = preview
            capturePreviewBitmap = bitmap
        } catch (_: WindowManager.BadTokenException) {
            bitmap.recycle()
            Toast.makeText(service, AppLanguage.translate("نمایش فریم ضبط‌شده ناموفق بود"), Toast.LENGTH_SHORT).show()
        }
    }

    private fun closeCapturePreview() {
        capturePreviewRoot?.let { runCatching { manager.removeView(it) } }
        capturePreviewRoot = null
        capturePreviewBitmap?.recycle()
        capturePreviewBitmap = null
    }

    private fun recordLabel(recording: Boolean = MacroAccessibilityService.recording) =
        if (recording) "■  پایان ضبط" else "● ضبط لمس"

    private fun editField(value: String, hint: String) = EditText(service).apply {
        setText(value)
        this.hint = AppLanguage.translate(hint)
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF8797A8.toInt())
        textSize = 14f
        setSingleLine(true)
        setPadding(dp(10), 0, dp(10), 0)
        background = rounded(0xFF101A25.toInt(), 0xFF3B4E61.toInt(), dp(9))
    }

    private fun button(label: String, color: Int, onClick: () -> Unit) = TextView(service).apply {
        text = AppLanguage.translate(label)
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = rounded(color, 0xFF536A80.toInt(), dp(10))
        isClickable = true
        isFocusable = true
        setOnClickListener { Handler(service.mainLooper).postDelayed({ onClick() }, 120L) }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(service).apply {
        text = AppLanguage.translate(value)
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), stroke)
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0, height: Int = LinearLayout.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int) = (value * service.resources.displayMetrics.density).roundToInt()
}
