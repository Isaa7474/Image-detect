package app.imagedetect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.os.Build.VERSION_CODES
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

data class CapturedFrame(val bitmap: Bitmap, val sequence: Long)

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var stopping = false
    private var workerHandler: Handler? = null
    private var captureWidth = 0
    private var captureHeight = 0
    private var lastPublishAt = 0L
    private var pendingImage: Image? = null
    private var flushScheduled = false
    private var displayListener: DisplayManager.DisplayListener? = null

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        MacroStore.initialize(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            MacroRunner.stop()
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (Build.VERSION.SDK_INT >= VERSION_CODES.Q) startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification())
        if (projection == null) {
            val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val data = projectionData(intent)
            if (data == null || code == 0) {
                MacroStore.status = "مجوز اشتراک‌گذاری صفحه دریافت نشد"
                stopSelf()
                return START_NOT_STICKY
            }
            startCapture(code, data)
        }
        // MediaProjection grants are one-shot. Restarting without the original
        // consent Intent would create a broken foreground service.
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun projectionData(intent: Intent?): Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_RESULT_DATA)

    private fun startCapture(resultCode: Int, data: Intent) {
        // Allow a reused service instance to clean up normally after restart.
        stopping = false
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val activeProjection = manager.getMediaProjection(resultCode, data)
        projection = activeProjection
        activeProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, Handler(mainLooper))

        val metrics = realMetrics()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        captureWidth = width
        captureHeight = height
        worker = HandlerThread("screen-capture").apply { start() }
        val handler = Handler(worker!!.looper)
        workerHandler = handler
        reader = newReader(width, height, handler)
        display = activeProjection.createVirtualDisplay(
            "ImageDetectCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler
        )
        // دنبال‌کردن چرخش صفحه تا فریم‌ها و مختصات لمس همیشه با صفحهٔ واقعی هم‌اندازه بمانند
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) { resizeCaptureIfNeeded() }
        }
        displayListener = listener
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(listener, handler)
        capturing = true
        MacroStore.status = "در انتظار اولین فریم از صفحهٔ اشتراکی..."
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    private fun newReader(width: Int, height: Int, handler: Handler): ImageReader =
        ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).also { imageReader ->
            imageReader.setOnImageAvailableListener({ source ->
                if (source !== reader) {
                    runCatching { source.acquireLatestImage()?.close() }
                    return@setOnImageAvailableListener
                }
                val image = (try { source.acquireLatestImage() } catch (_: Exception) { null }) ?: return@setOnImageAvailableListener
                val wait = FRAME_INTERVAL_MS - (SystemClock.elapsedRealtime() - lastPublishAt)
                if (wait <= 0L) {
                    pendingImage?.let { runCatching { it.close() } }
                    pendingImage = null
                    publishSafely(image)
                } else {
                    // آخرین فریم هیچ‌وقت دور ریخته نمی‌شود؛ فقط کمی دیرتر منتشر می‌شود
                    pendingImage?.let { runCatching { it.close() } }
                    pendingImage = image
                    if (!flushScheduled) {
                        flushScheduled = true
                        handler.postDelayed({
                            flushScheduled = false
                            val waiting = pendingImage
                            pendingImage = null
                            if (waiting != null) publishSafely(waiting)
                        }, wait)
                    }
                }
            }, handler)
        }

    private fun publishSafely(image: Image) {
        lastPublishAt = SystemClock.elapsedRealtime()
        try { publish(image) } catch (error: Exception) {
            runCatching { image.close() }
            Log.e("ImageDetect", "Could not convert captured frame", error)
            MacroStore.status = "گرفتن تصویر ناموفق بود؛ دوباره اشتراک‌گذاری را شروع کنید"
        }
    }

    private fun resizeCaptureIfNeeded() {
        val virtualDisplay = display ?: return
        val handler = workerHandler ?: return
        val metrics = realMetrics()
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        if (width == captureWidth && height == captureHeight) return
        try {
            pendingImage?.let { runCatching { it.close() } }
            pendingImage = null
            val oldReader = reader
            val freshReader = newReader(width, height, handler)
            reader = freshReader
            captureWidth = width
            captureHeight = height
            virtualDisplay.resize(width, height, metrics.densityDpi)
            virtualDisplay.surface = freshReader.surface
            runCatching { oldReader?.close() }
            clearLatest()
            MacroStore.status = "چرخش صفحه تشخیص داده شد؛ اندازهٔ تصویر زنده به‌روز شد"
        } catch (error: Exception) {
            Log.e("ImageDetect", "Could not resize capture", error)
        }
    }

    private fun refreshCaptureSurface(): Long {
        val handler = workerHandler ?: return frameSequence()
        val surfaceAttached = CountDownLatch(1)
        handler.post {
            try {
                val virtualDisplay = display ?: return@post
                val oldReader = reader ?: return@post
                val freshReader = runCatching { newReader(captureWidth, captureHeight, handler) }.getOrElse {
                    Log.e("ImageDetect", "Could not refresh capture surface", it)
                    return@post
                }
                reader = freshReader
                try {
                    virtualDisplay.surface = null
                    virtualDisplay.surface = freshReader.surface
                    runCatching { oldReader.close() }
                } catch (error: Exception) {
                    reader = oldReader
                    runCatching { virtualDisplay.surface = oldReader.surface }
                    runCatching { freshReader.close() }
                    throw error
                }
            } catch (error: Exception) {
                Log.e("ImageDetect", "Could not refresh capture surface", error)
            } finally {
                surfaceAttached.countDown()
            }
        }
        try {
            surfaceAttached.await(500L, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        return frameSequence()
    }

    private fun publish(image: Image) {
        image.use {
            val plane = it.planes[0]
            val pixelStride = plane.pixelStride
            val rowPixels = plane.rowStride / pixelStride
            val frame = if (rowPixels == it.width) {
                Bitmap.createBitmap(it.width, it.height, Bitmap.Config.ARGB_8888).also { bitmap ->
                    bitmap.copyPixelsFromBuffer(plane.buffer)
                }
            } else {
                val padded = Bitmap.createBitmap(rowPixels, it.height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(padded, 0, 0, it.width, it.height)
                padded.recycle()
                cropped
            }
            val firstFrame = !hasFrame()
            replaceLatest(frame)
            if (firstFrame) {
                MacroStore.status = "تصویر زنده دریافت شد؛ آمادهٔ ضبط"
                Handler(mainLooper).post { MacroAccessibilityService.instance?.refreshFloatingMenu() }
            }
        }
    }

    private fun notification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val channelName = when (AppLanguage.current) {
                "en" -> "Screen sharing"
                "ru" -> "Показ экрана"
                else -> "اشتراک‌گذاری صفحه"
            }
            val channel = NotificationChannel(CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val stop = Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(when (AppLanguage.current) { "ru" -> "Image Detect работает"; "fa" -> "Image Detect فعال است"; else -> "Image Detect is active" })
            .setContentText(when (AppLanguage.current) {
                "ru" -> "Поиск изображений выполняется на устройстве. Нажмите «Стоп», чтобы остановить захват и воспроизведение."
                "fa" -> "تطبیق تصویر روی خود دستگاه انجام می‌شود. برای پایان ضبط صفحه و اجرا، توقف را بزنید."
                else -> "Screen matching is on-device. Tap Stop to end capture and playback."
            })
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, when (AppLanguage.current) { "ru" -> "Стоп"; "fa" -> "توقف"; else -> "Stop" }, pending)
            .build()
    }

    private fun stopCapture() {
        if (stopping) return
        stopping = true
        MacroAccessibilityService.recording = false
        MacroAccessibilityService.instance?.refreshFloatingMenu()
        displayListener?.let { runCatching { (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) } }
        displayListener = null
        pendingImage?.let { runCatching { it.close() } }
        pendingImage = null
        display?.release(); display = null
        reader?.close(); reader = null
        worker?.quitSafely(); worker = null
        val old = projection
        projection = null
        old?.stop()
        clearLatest()
        capturing = false
        MacroAccessibilityService.instance?.setRecording(false)
        MacroStore.status = "اشتراک‌گذاری صفحه متوقف شد"
    }

    override fun onDestroy() {
        stopCapture()
        if (activeInstance === this) activeInstance = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "app.imagedetect.STOP_CAPTURE"
        private const val CHANNEL_ID = "image_detect_capture"
        private const val NOTIFICATION_ID = 407
        private const val FRAME_INTERVAL_MS = 80L
        @Volatile private var activeInstance: ScreenCaptureService? = null
        @Volatile private var latest: Bitmap? = null
        private var latestSequence = 0L
        @Volatile var capturing = false
        private val bitmapLock = Any()

        fun latestFrame(): Bitmap? = synchronized(bitmapLock) { latest?.copy(Bitmap.Config.ARGB_8888, false) }
        fun hasFrame(): Boolean = synchronized(bitmapLock) { latest != null }
        fun frameSequence(): Long = synchronized(bitmapLock) { latestSequence }

        fun requestFreshFrame(): Long = activeInstance?.refreshCaptureSurface() ?: frameSequence()

        fun freshFrameSnapshot(timeoutMs: Long = 1_200L): CapturedFrame? {
            val afterSequence = requestFreshFrame()
            val deadline = SystemClock.elapsedRealtime() + timeoutMs
            while (frameSequence() <= afterSequence && SystemClock.elapsedRealtime() < deadline) {
                try {
                    Thread.sleep(20L)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                }
            }
            return latestFrameSnapshot()?.takeIf { it.sequence > afterSequence }
        }

        fun latestFrameSnapshot(): CapturedFrame? = synchronized(bitmapLock) {
            latest?.copy(Bitmap.Config.ARGB_8888, false)?.let { CapturedFrame(it, latestSequence) }
        }

        private fun replaceLatest(bitmap: Bitmap) = synchronized(bitmapLock) {
            latest?.recycle()
            latest = bitmap
            latestSequence++
        }

        private fun clearLatest() = synchronized(bitmapLock) {
            latest?.recycle()
            latest = null
        }
    }
}
